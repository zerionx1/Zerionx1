#!/usr/bin/env bash
set -euo pipefail
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f package.json ] || [ ! -d src ]; then
  echo "Run this from the existing Zerion X1 repo root."
  exit 1
fi

echo "===== Zerion X1 FixPack 2/3 ====="
python3 "$PACK_DIR/patches/apply_pack2.py"

echo
echo "===== TYPECHECK ====="
npm run typecheck

echo
echo "FixPack 2 applied."
echo "Next: npm run test && npm run build"
