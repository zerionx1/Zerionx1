# Zerion X1 FixPack 2/3 — Bidirectional Opportunity + Risk Engine

This pack continues the existing repository and assumes Pack 1 has already been applied.

## Root causes found in current repo
- `deterministic-scanner.ts` decides direction mainly from one number: session `changePercent`.
- Confidence is derived from the absolute session move rather than a real multi-factor setup.
- `opportunity-store.ts` hard-codes every opportunity to exactly 60 minutes.
- Cron default universe is heavily concentrated in BTC/ETH/SOL + a few Indian symbols.
- Opportunity notifications do not include a complete risk plan.

## Fixes
- Symmetric LONG and SHORT scoring (no structural LONG bias).
- Uses session %, price vs open, price vs previous close and location inside session high/low range.
- Neutral/no-trade when confirmation is mixed.
- Complete trade plan: side, entry, SL, T1/T2/T3, trailing trigger/distance, R:R, max-loss %, max-profit %, invalidation.
- Dynamic setup validity (not fixed one hour).
- 15-minute anti-spam/regime fingerprint instead of one-hour fingerprint.
- Broader India + crypto + forex/metals scan universe; unsupported symbols simply do not produce provider quotes.
- Push/in-app notification contains actual side, entry, SL and targets.
- User approval remains mandatory for execution.

## Apply
```bash
cd ~/Projects/zerion-x1
rm -rf /tmp/zxpack2 && mkdir -p /tmp/zxpack2
unzip -o /path/to/ZerionX1_FixPack_2_Opportunity_Risk.zip -d /tmp/zxpack2
bash /tmp/zxpack2/APPLY_FIXPACK_2.sh
npm run test
npm run build
```

## Accuracy
This removes obvious logic flaws and creates a materially stronger, bidirectional deterministic fallback. It does not and cannot guarantee a 70–80% live-market win rate. That target has to be measured with forward testing/backtests and then calibrated without look-ahead bias.
