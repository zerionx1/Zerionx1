#!/usr/bin/env python3
from pathlib import Path
import shutil, time

repo = Path.cwd()
pack = Path(__file__).resolve().parent.parent

mapping = {
    "patches/deterministic-scanner.ts": "src/lib/agents/deterministic-scanner.ts",
    "patches/opportunity-store.ts": "src/lib/agents/opportunity-store.ts",
    "patches/market-scan-route.ts": "src/app/api/automation/market-scan/route.ts",
    "patches/opportunity-dispatch.ts": "src/lib/notifications/opportunity-dispatch.ts",
}

missing = [dst for dst in mapping.values() if not (repo/dst).exists()]
if missing:
    raise SystemExit("FixPack 2: expected repo files missing: " + ", ".join(missing))

stamp = time.strftime("%Y%m%d-%H%M%S")
backup = repo/".fixpack-backups"/("pack2-"+stamp)

for src_rel, dst_rel in mapping.items():
    dst = repo/dst_rel
    b = backup/dst_rel
    b.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(dst, b)
    shutil.copy2(pack/src_rel, dst)

print("FixPack 2 applied.")
print("Backup:", backup)
