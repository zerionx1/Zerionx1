Zerion X1 FixPack 8.2.1 — Strict Four UI + GoCharting Proxy

Base: commit 56e1b2f or newer.

Fixes:
- Keeps dashboard UI constrained to the four approved colours only:
  #F7F4ED #2F2A25 #3E4A3F #E6D8C3
- Applies strict dashboard/home/markets readability overrides after legacy CSS.
- Reworks home command center layout from FixPack 8.2.
- Keeps mobile/desktop spacing and white-space animation corrections from FixPack 8.2.
- Removes reliance on npm install @gocharting/chart-sdk because the public npm registry currently returns 404.
- Loads the official GoCharting UMD build through a same-origin Zerion API proxy at /api/gocharting/sdk.
- Does not inject a demo license key or bypass GoCharting licensing.

Apply script intentionally does NOT run typecheck/tests/build. Run them separately after apply.
