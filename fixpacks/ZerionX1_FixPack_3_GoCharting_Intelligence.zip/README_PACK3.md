# Zerion X1 FixPack 3/3 — GoCharting Runtime + Market Intelligence UI

This pack is meant for the existing `zerionx1/Zerionx1` repository after Pack 1 and Pack 2.

## What this pack does

### 1) Actual GoCharting runtime mount
- Installs the official package from the current official docs:
  `@gocharting/chart-sdk`
- Replaces the Pack-1 placeholder host with an actual dynamic GoCharting chart runtime.
- Uses Zerion's provider-backed custom Datafeed implementation for:
  - symbol resolve/search,
  - historical OHLCV,
  - realtime bars,
  - India / crypto / forex symbols present in Zerion's market catalog.
- If GoCharting fails to initialize, the existing Zerion chart remains a safety fallback.
- Chart loading uses a soft blurred/skeleton stage. GoCharting branding is not hidden or modified; attribution appears once the chart is rendered.

### 2) Official GoCharting Datafeed shape
Implements the SDK callbacks documented by GoCharting:
- onReady
- searchSymbols
- resolveSymbol
- getBars
- subscribeBars
- unsubscribeBars

### 3) Market Intelligence workspace
Expands `/dashboard/intelligence` into a cleaner market workspace with:
- Technical Screener
- Market News Analysis
- Fundamental Analysis status
- Options / Greeks / IV status
- Existing AI Chart Intelligence preserved

The pack does not fabricate fundamentals, options-chain numbers or headlines.
News is fetched from a live RSS search endpoint and scored conservatively.
Fundamental/options cards explicitly show data availability rather than fake values.

### 4) Mobile + desktop cleanup
- Larger typography
- cleaner card spacing
- responsive intelligence grid
- mobile-safe chart loading state
- subtle chart-engine badge

## GoCharting licensing note

GoCharting's public "AI-Driven Charting Library" page currently advertises a free attribution tier, while the SDK documentation also shows a `licenseKey` and says production SDK usage requires a commercial license. Because those official pages conflict, this pack supports both:

- `NEXT_PUBLIC_GOCHARTING_LICENSE_KEY` — optional runtime key
- free-attribution attempt when no key is configured
- automatic fallback if the installed SDK rejects unlicensed production use

Do not remove or conceal required GoCharting attribution.

## Apply

```bash
cd ~/Projects/zerion-x1

rm -rf /tmp/zxpack3
mkdir -p /tmp/zxpack3
unzip -o /path/to/ZerionX1_FixPack_3_GoCharting_Intelligence.zip -d /tmp/zxpack3

bash /tmp/zxpack3/APPLY_FIXPACK_3.sh

npm run test
npm run build
```

Optional Vercel env:
```bash
NEXT_PUBLIC_ZERION_CHART_ENGINE=gocharting
NEXT_PUBLIC_GOCHARTING_LICENSE_KEY=
```
