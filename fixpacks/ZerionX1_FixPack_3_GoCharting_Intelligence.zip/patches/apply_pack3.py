#!/usr/bin/env python3
from pathlib import Path
import shutil, time

repo = Path.cwd()
pack = Path(__file__).resolve().parent.parent

required = [
    repo / "package.json",
    repo / "src/app/globals.css",
    repo / "src/components/markets/market-chart-terminal.tsx",
    repo / "src/components/intelligence/chart-intelligence-lab.tsx",
    repo / "src/app/dashboard/intelligence/page.tsx",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    raise SystemExit("FixPack 3: expected Zerion repo files missing: " + ", ".join(missing))

# Pack-1 guard.
terminal = (repo / "src/components/markets/market-chart-terminal.tsx").read_text()
if "GoChartingChartHost" not in terminal:
    raise SystemExit(
        "FixPack 3 expects FixPack 1 first: GoChartingChartHost is not mounted in market-chart-terminal.tsx"
    )

# Pack-2 guard.
scanner = repo / "src/lib/agents/deterministic-scanner.ts"
if scanner.exists():
    source = scanner.read_text()
    if "tradePlan" not in source or "short-watch" not in source:
        raise SystemExit(
            "FixPack 3 expects FixPack 2 first: upgraded tradePlan/SHORT engine not detected."
        )

stamp = time.strftime("%Y%m%d-%H%M%S")
backup = repo / ".fixpack-backups" / ("pack3-" + stamp)

targets = [
    "src/components/markets/gocharting-chart-host.tsx",
    "src/app/dashboard/intelligence/page.tsx",
    "src/app/globals.css",
]
for rel in targets:
    src = repo / rel
    if src.exists():
        dst = backup / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

new_files = [
    "src/lib/gocharting/official-datafeed.ts",
    "src/components/markets/gocharting-chart-host.tsx",
    "src/components/intelligence/market-intelligence-hub.tsx",
    "src/app/dashboard/intelligence/page.tsx",
    "src/app/api/intelligence/news/route.ts",
]
for rel in new_files:
    src = pack / rel
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

css_path = repo / "src/app/globals.css"
css = css_path.read_text()
marker = "/* Zerion X1 FixPack 3 — GoCharting runtime + Intelligence */"
addition = (pack / "patches/pack3.css").read_text()
if marker not in css:
    css += "\n\n" + addition + "\n"
css_path.write_text(css)

print("FixPack 3 files applied.")
print("Backup:", backup)
