ZERION X1 FIXPACK 8.1 — COMBINED COMPLETE PACK

This pack supersedes FixPack 8. Do NOT apply the old FixPack 8 first.
Expected repo base: b0dc88e or a descendant, with a clean worktree.

Included:
- FixPack 8 GoCharting loader/datafeed/realtime repair.
- Canonical four-colour UI and removal of the five legacy global theme layers.
- Continuous scan/revalidation and feed reconnect/noise suppression from FixPack 8.
- User-confirmed paper risk-limit override behavior from FixPack 8.
- Notification dedupe + mark-current-batch-read when notification bell is opened.
- Realtime notification stable-key memory so duplicate event IDs do not re-toast endlessly.
- Paper position exit button.
- Upstox real position exit button using existing square-off endpoint.
- Exness MT5 real position exit button using existing MT5 close endpoint.
- CoinDCX wallet balances remain holdings (not falsely presented as closable margin positions).
- AI usage_counters RLS error fixed by moving quota writes to the existing server-only admin REST path while keeping owner scoping.
- Desktop vertical scrolling / page height stabilization.
- Animated ivory-space dashboard background with subtle stars and shooting-star motion using only the approved four-colour system.

Approved colours only in canonical theme:
#F7F4ED
#2F2A25
#3E4A3F
#E6D8C3

Apply:
bash APPLY_FIXPACK_8_1.sh

The script performs backup, diff check, typecheck, tests and production build.
