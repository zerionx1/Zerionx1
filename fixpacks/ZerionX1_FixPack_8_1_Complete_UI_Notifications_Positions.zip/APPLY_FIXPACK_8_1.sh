#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

REPO="${1:-$HOME/Projects/zerion-x1}"
PACK_DIR="$(cd "$(dirname "$0")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$HOME/.zerion-fixpack8-1-backup-$STAMP"

cd "$REPO"

if [ ! -f package.json ] || [ ! -d src ]; then
  echo "ERROR: Zerion X1 repo not found at $REPO"
  exit 1
fi

if ! git merge-base --is-ancestor b0dc88e HEAD >/dev/null 2>&1; then
  echo "ERROR: FixPack 8.1 expects b0dc88e (or a descendant) as repo base."
  echo "Current HEAD: $(git rev-parse --short HEAD)"
  exit 1
fi

if [ -n "$(git status --porcelain)" ]; then
  echo "ERROR: Worktree is not clean. Commit/stash/reset current changes first."
  git status --short
  exit 1
fi

echo "===== FIXPACK 8.1 BACKUP ====="
mkdir -p "$BACKUP"
for f in \
  src/app/globals.css \
  src/app/zerion-final-four.css \
  src/app/zerion-premium.css \
  src/app/phase-13-premium.css \
  src/app/final-prepush.css \
  src/app/zerion-luxury-palette.css \
  src/app/zerion-luxury-v2.css \
  src/components/markets/gocharting-chart-host.tsx \
  src/lib/gocharting/official-datafeed.ts \
  src/components/markets/market-chart-terminal.tsx \
  src/components/alerts/deterministic-market-alert-runtime.tsx \
  src/hooks/use-zerion-market-stream.ts \
  src/app/api/notifications/inbox/route.ts \
  src/components/notifications/agent-opportunity-inbox.tsx \
  src/components/notifications/realtime-notification-center.tsx \
  src/components/portfolio/unified-positions-center.tsx \
  src/lib/billing/quotas.ts \
  src/lib/paper/paper-engine.ts \
  src/lib/execution/opportunity-executor.ts \
  'src/app/api/agents/opportunities/[opportunityId]/approve/route.ts' \
  src/workers/background-ai-loop.ts \
  src/app/api/automation/market-scan/route.ts \
  src/lib/agents/opportunity-store.ts
 do
  if [ -e "$f" ]; then
    mkdir -p "$BACKUP/$(dirname "$f")"
    cp -a "$f" "$BACKUP/$f"
  fi
 done

echo "Backup: $BACKUP"

echo
echo "===== APPLY FIXPACK 8.1 FILES ====="
cp -a "$PACK_DIR/src/." "$REPO/src/"

# Remove legacy theme layers which conflict with the canonical four-colour layer.
sed -i \
  -e '/@import "\.\/zerion-premium\.css";/d' \
  -e '/@import "\.\/phase-13-premium\.css";/d' \
  -e '/@import "\.\/final-prepush\.css";/d' \
  -e '/@import "\.\/zerion-luxury-palette\.css";/d' \
  -e '/@import "\.\/zerion-luxury-v2\.css";/d' \
  src/app/globals.css

rm -f \
  src/app/zerion-premium.css \
  src/app/phase-13-premium.css \
  src/app/final-prepush.css \
  src/app/zerion-luxury-palette.css \
  src/app/zerion-luxury-v2.css

rm -rf .next

echo
echo "===== FOUR-COLOUR CHECK ====="
BAD_COLORS="$(grep -Eo '#[0-9A-Fa-f]{6}' src/app/zerion-final-four.css | tr 'a-f' 'A-F' | sort -u | grep -Ev '^#(F7F4ED|2F2A25|3E4A3F|E6D8C3)$' || true)"
if [ -n "$BAD_COLORS" ]; then
  echo "ERROR: non-approved hex colours in canonical theme:"
  echo "$BAD_COLORS"
  exit 1
fi
for f in \
  src/app/zerion-premium.css \
  src/app/phase-13-premium.css \
  src/app/final-prepush.css \
  src/app/zerion-luxury-palette.css \
  src/app/zerion-luxury-v2.css
 do
  if [ -e "$f" ]; then
    echo "ERROR: legacy theme file still exists: $f"
    exit 1
  fi
 done

echo "Canonical colours: #F7F4ED #2F2A25 #3E4A3F #E6D8C3"

echo
echo "===== REQUIRED FIX CHECK ====="
grep -q 'adminSelect' src/lib/billing/quotas.ts
grep -q 'all?: boolean' src/app/api/notifications/inbox/route.ts
grep -q 'Exit paper position' src/components/portfolio/unified-positions-center.tsx
grep -q 'Exit real position' src/components/portfolio/unified-positions-center.tsx
grep -q 'zxShootingStar' src/app/zerion-final-four.css
grep -q 'GOCHARTING' src/components/markets/gocharting-chart-host.tsx || true

echo
echo "===== DIFF CHECK ====="
git diff --check

echo
echo "===== TYPECHECK ====="
npm run typecheck

echo
echo "===== TESTS ====="
npm test

echo
echo "===== BUILD ====="
npm run build

echo
echo "===== FINAL STATUS ====="
git status --short

echo
echo "✅ FIXPACK 8.1 APPLIED + TYPECHECK + TESTS + BUILD PASSED"
echo "Backup kept at: $BACKUP"
