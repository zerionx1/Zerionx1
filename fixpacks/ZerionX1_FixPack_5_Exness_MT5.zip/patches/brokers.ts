import type { BrokerAdapterDescriptor } from "@/types/broker";
export const brokerCatalog: BrokerAdapterDescriptor[]=[
{key:"upstox",name:"Upstox",kind:"india",authMode:"oauth",supportsSandbox:true,availability:"available",description:"Indian market execution through Upstox.",createAccountUrl:"https://upstox.onelink.me/0H1s/75BFXW",capabilities:{marketData:true,orders:true,positions:true,funds:true,websocket:true}},
{key:"exness-mt5",name:"Exness MT5",kind:"forex",authMode:"session",supportsSandbox:true,availability:"available",description:"Forex execution through Zerion MT5 Bridge connected to Exness MetaTrader 5.",createAccountUrl:"https://www.exness.com/",capabilities:{marketData:true,orders:true,positions:true,funds:true,websocket:false}},
{key:"coindcx",name:"CoinDCX",kind:"crypto",authMode:"api-key",supportsSandbox:false,availability:"available",description:"Crypto execution and account access through CoinDCX.",createAccountUrl:"https://coindcx.com/",capabilities:{marketData:true,orders:true,positions:true,funds:true,websocket:true}}
];
