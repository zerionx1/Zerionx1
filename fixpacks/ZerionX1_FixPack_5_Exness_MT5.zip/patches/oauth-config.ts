import "server-only";
export type OAuthBrokerKey="upstox";
export function callbackUrl(request:Request,_broker:OAuthBrokerKey){const c=process.env.UPSTOX_REDIRECT_URI;if(c)return c;const app=process.env.NEXT_PUBLIC_APP_URL??new URL(request.url).origin;return `${app}/api/brokers/upstox/callback`;}
export function brokerConfigured(_:OAuthBrokerKey){return Boolean(process.env.UPSTOX_CLIENT_ID&&process.env.UPSTOX_CLIENT_SECRET&&process.env.BROKER_TOKEN_ENCRYPTION_KEY);}
export function authorizationUrl(request:Request,_broker:OAuthBrokerKey,state:string){const id=process.env.UPSTOX_CLIENT_ID;if(!id)throw new Error("UPSTOX_CLIENT_ID is not configured");const u=new URL("https://api.upstox.com/v2/login/authorization/dialog");u.searchParams.set("response_type","code");u.searchParams.set("client_id",id);u.searchParams.set("redirect_uri",callbackUrl(request,"upstox"));u.searchParams.set("state",state);return u.toString();}
