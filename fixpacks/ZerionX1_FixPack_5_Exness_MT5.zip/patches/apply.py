from pathlib import Path
import shutil,time
repo=Path.cwd();pack=Path(__file__).resolve().parent.parent
req=[repo/"src/config/brokers.ts",repo/"src/lib/brokers/oauth-config.ts",repo/"src/app/api/brokers/route.ts",repo/"src/components/brokers/broker-connection-center.tsx"]
miss=[str(x) for x in req if not x.exists()]
if miss: raise SystemExit("Missing: "+", ".join(miss))
backup=repo/".fixpack-backups"/("pack5-"+time.strftime("%Y%m%d-%H%M%S"))
for x in req:
 d=backup/x.relative_to(repo);d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(x,d)
for rel in ["src/app/api/brokers/ctrader","src/app/api/live/ctrader","src/lib/brokers/ctrader-json-client.ts"]:
 x=repo/rel
 if x.exists():
  d=backup/rel;d.parent.mkdir(parents=True,exist_ok=True)
  if x.is_dir(): shutil.copytree(x,d,dirs_exist_ok=True);shutil.rmtree(x)
  else: shutil.copy2(x,d);x.unlink()
shutil.copy2(pack/"patches/brokers.ts",repo/"src/config/brokers.ts")
shutil.copy2(pack/"patches/oauth-config.ts",repo/"src/lib/brokers/oauth-config.ts")
for src in (pack/"src").rglob("*"):
 if src.is_file():
  dst=repo/src.relative_to(pack);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
dst=repo/"mt5-bridge";dst.mkdir(exist_ok=True)
for src in (pack/"mt5-bridge").rglob("*"):
 if src.is_file():
  out=dst/src.relative_to(pack/"mt5-bridge");out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,out)
p=repo/"src/app/api/brokers/route.ts";s=p.read_text()
s=s.replace('import { sealBrokerSecret } from "@/lib/brokers/token-vault";','import { sealBrokerSecret } from "@/lib/brokers/token-vault";\nimport { mt5BridgeClient, mt5BridgeConfigured } from "@/lib/brokers/mt5-bridge-client";')
s=s.replace('return key === "upstox" || key === "ctrader";','return key === "upstox";')
old='  if (key === "coindcx") {\n    return Boolean(process.env.BROKER_TOKEN_ENCRYPTION_KEY);\n  }\n  return isOAuthBroker(key) ? brokerConfigured(key) : false;'
new='  if (key === "coindcx") return Boolean(process.env.BROKER_TOKEN_ENCRYPTION_KEY);\n  if (key === "exness-mt5") return mt5BridgeConfigured();\n  return isOAuthBroker(key) ? brokerConfigured(key) : false;'
if old in s:s=s.replace(old,new,1)
anchor='  if (!isOAuthBroker(broker.key)) {\n    return fail(\n      "BROKER_NOT_CONFIGURED",\n      `${broker.name} is not enabled in this release.`,\n      503,\n    );\n  }'
block='  if (broker.key === "exness-mt5") {\n    if (!mt5BridgeConfigured()) return fail("BROKER_NOT_CONFIGURED","MT5 bridge is not configured.",503);\n    try {\n      const health = await mt5BridgeClient.health();\n      const existing = (await select("broker_connections",`owner_id=eq.${user.id}&broker_key=eq.exness-mt5&limit=1`))[0];\n      const metadata={provider:"exness-mt5",auth_mode:"bridge",verified_at:new Date().toISOString(),bridge_health:health};\n      if(existing) await update("broker_connections",`id=eq.${String(existing.id)}&owner_id=eq.${user.id}`,{status:"connected",metadata,updated_at:new Date().toISOString()});\n      else await insert("broker_connections",{owner_id:user.id,broker_key:"exness-mt5",display_name:"Exness MT5",status:"connected",metadata});\n      return ok({connected:true,brokerKey:"exness-mt5",authMode:"bridge"});\n    } catch(error) { return fail("BROKER_AUTH_FAILED",error instanceof Error?error.message:"MT5 bridge verification failed",502); }\n  }\n\n'+anchor
if anchor not in s: raise SystemExit("Broker route anchor changed")
s=s.replace(anchor,block,1);p.write_text(s)
p=repo/"src/components/brokers/broker-connection-center.tsx";s=p.read_text();s=s.replace('copy: "Forex bridge integration is handled separately and is not enabled in this pack.",','copy: "Forex execution uses Exness MetaTrader 5 through the Zerion MT5 Bridge.",');s=s.replace('              {value === "forex" ? (\n                <small>Coming soon</small>\n              ) : null}','');p.write_text(s)
print("FixPack 5 applied",backup)
