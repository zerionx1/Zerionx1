import os, threading, hashlib
from fastapi import FastAPI, Header, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Literal, Optional
import MetaTrader5 as mt5
app=FastAPI(title="Zerion X1 MT5 Bridge")
TOKEN=os.getenv("MT5_BRIDGE_TOKEN",""); LOGIN=int(os.getenv("MT5_LOGIN","0") or 0); PASSWORD=os.getenv("MT5_PASSWORD",""); SERVER=os.getenv("MT5_SERVER",""); MODE=os.getenv("MT5_MODE","demo"); PATH=os.getenv("MT5_TERMINAL_PATH","") or None
lock=threading.RLock(); seen={}
def auth(authorization:str|None=Header(default=None)):
    if not TOKEN or authorization!=f"Bearer {TOKEN}": raise HTTPException(401,"Unauthorized")
def ready():
    kw=dict(login=LOGIN,password=PASSWORD,server=SERVER); ok=mt5.initialize(PATH,**kw) if PATH else mt5.initialize(**kw)
    if not ok: raise HTTPException(503,f"MT5 initialize failed: {mt5.last_error()}")
def asdict(x): return x._asdict() if hasattr(x,"_asdict") else dict(x)
class Order(BaseModel):
    symbol:str; side:Literal["buy","sell"]; volume:float=Field(gt=0,le=100); stop_loss:Optional[float]=None; take_profit:Optional[float]=None; deviation:int=20; comment:str="Zerion X1"
class Modify(BaseModel):
    ticket:int; stop_loss:Optional[float]=None; take_profit:Optional[float]=None
class Close(BaseModel):
    ticket:int; volume:Optional[float]=None; deviation:int=20
def req(o:Order):
    if not mt5.symbol_select(o.symbol,True): raise HTTPException(404,f"Symbol unavailable: {o.symbol}")
    t=mt5.symbol_info_tick(o.symbol); buy=o.side=="buy"
    if not t: raise HTTPException(503,"No tick")
    price=t.ask if buy else t.bid
    if o.stop_loss is not None and ((buy and o.stop_loss>=price) or ((not buy) and o.stop_loss<=price)): raise HTTPException(400,"Invalid stop loss")
    if o.take_profit is not None and ((buy and o.take_profit<=price) or ((not buy) and o.take_profit>=price)): raise HTTPException(400,"Invalid take profit")
    return {"action":mt5.TRADE_ACTION_DEAL,"symbol":o.symbol,"volume":o.volume,"type":mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL,"price":price,"sl":o.stop_loss or 0.0,"tp":o.take_profit or 0.0,"deviation":o.deviation,"magic":510001,"comment":o.comment[:31],"type_time":mt5.ORDER_TIME_GTC,"type_filling":mt5.ORDER_FILLING_IOC}
@app.get("/health",dependencies=[Depends(auth)])
def health():
    with lock: ready(); a=mt5.account_info(); return {"ok":bool(a),"mode":MODE,"server":SERVER,"login":LOGIN}
@app.get("/account",dependencies=[Depends(auth)])
def account():
    with lock:
        ready(); a=mt5.account_info()
        if not a: raise HTTPException(503,"No account info")
        d=asdict(a); d["mode"]=MODE; return d
@app.get("/positions",dependencies=[Depends(auth)])
def positions():
    with lock: ready(); p=mt5.positions_get() or []; return {"count":len(p),"positions":[asdict(x) for x in p]}
@app.post("/order/place",dependencies=[Depends(auth)])
def place(o:Order,x_idempotency_key:str|None=Header(default=None)):
    if not x_idempotency_key: raise HTTPException(400,"x-idempotency-key required")
    k=hashlib.sha256(x_idempotency_key.encode()).hexdigest()
    if k in seen:return seen[k]
    with lock:
        ready(); r=req(o); chk=mt5.order_check(r)
        if chk is None: raise HTTPException(409,f"order_check failed: {mt5.last_error()}")
        res=mt5.order_send(r)
        if res is None: raise HTTPException(503,f"order_send failed: {mt5.last_error()}")
        d=asdict(res); d["ok"]=res.retcode==mt5.TRADE_RETCODE_DONE; d["mode"]=MODE; seen[k]=d; return d
@app.post("/order/modify",dependencies=[Depends(auth)])
def modify(m:Modify):
    with lock:
        ready(); p=mt5.positions_get(ticket=m.ticket) or []
        if not p: raise HTTPException(404,"Position not found")
        pos=p[0]; res=mt5.order_send({"action":mt5.TRADE_ACTION_SLTP,"position":m.ticket,"symbol":pos.symbol,"sl":m.stop_loss or 0.0,"tp":m.take_profit or 0.0,"magic":510001})
        if res is None: raise HTTPException(503,"Modify failed")
        return asdict(res)
@app.post("/order/close",dependencies=[Depends(auth)])
def close(c:Close):
    with lock:
        ready(); p=mt5.positions_get(ticket=c.ticket) or []
        if not p: raise HTTPException(404,"Position not found")
        pos=p[0]; t=mt5.symbol_info_tick(pos.symbol); buy=pos.type==mt5.POSITION_TYPE_BUY
        res=mt5.order_send({"action":mt5.TRADE_ACTION_DEAL,"position":c.ticket,"symbol":pos.symbol,"volume":c.volume or pos.volume,"type":mt5.ORDER_TYPE_SELL if buy else mt5.ORDER_TYPE_BUY,"price":t.bid if buy else t.ask,"deviation":c.deviation,"magic":510001,"comment":"Zerion X1 close","type_time":mt5.ORDER_TIME_GTC,"type_filling":mt5.ORDER_FILLING_IOC})
        if res is None: raise HTTPException(503,"Close failed")
        return asdict(res)
