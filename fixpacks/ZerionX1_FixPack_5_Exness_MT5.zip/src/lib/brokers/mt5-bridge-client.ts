import "server-only";

type Json = Record<string, unknown>;
function base(){const v=process.env.MT5_BRIDGE_URL?.trim();if(!v)throw new Error("MT5_BRIDGE_URL is not configured");return v.replace(/\/+$/,"");}
function token(){const v=process.env.MT5_BRIDGE_TOKEN?.trim();if(!v)throw new Error("MT5_BRIDGE_TOKEN is not configured");return v;}
async function call<T>(path:string,init?:RequestInit):Promise<T>{const r=await fetch(`${base()}${path}`,{...init,cache:"no-store",headers:{authorization:`Bearer ${token()}`,accept:"application/json",...(init?.body?{"content-type":"application/json"}:{}),...(init?.headers??{})}});const b=await r.json().catch(()=>({}));if(!r.ok)throw new Error(b.detail??b.message??`MT5 bridge ${r.status}`);return b as T;}
export function mt5BridgeConfigured(){return Boolean(process.env.MT5_BRIDGE_URL?.trim()&&process.env.MT5_BRIDGE_TOKEN?.trim());}
export const mt5BridgeClient={health:()=>call<Json>("/health"),account:()=>call<Json>("/account"),positions:()=>call<Json>("/positions"),place:(body:Json,key:string)=>call<Json>("/order/place",{method:"POST",headers:{"x-idempotency-key":key},body:JSON.stringify(body)}),modify:(body:Json)=>call<Json>("/order/modify",{method:"POST",body:JSON.stringify(body)}),close:(body:Json)=>call<Json>("/order/close",{method:"POST",body:JSON.stringify(body)})};
