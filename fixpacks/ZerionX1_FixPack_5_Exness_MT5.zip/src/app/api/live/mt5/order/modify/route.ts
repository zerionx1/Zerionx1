import { mt5BridgeClient } from "@/lib/brokers/mt5-bridge-client";
import { fail, ok } from "@/lib/security/api-response";
import { currentUser } from "@/lib/supabase/rest";
export async function POST(request:Request){await currentUser();const b=await request.json().catch(()=>null) as any;if(!Number.isFinite(b?.ticket))return fail("VALIDATION_ERROR","ticket is required",400);try{return ok(await mt5BridgeClient.modify({ticket:Number(b.ticket),stop_loss:b.stopLoss??null,take_profit:b.takeProfit??null}))}catch(e){return fail("MT5_MODIFY_FAILED",e instanceof Error?e.message:"MT5 modify failed",502)}}
