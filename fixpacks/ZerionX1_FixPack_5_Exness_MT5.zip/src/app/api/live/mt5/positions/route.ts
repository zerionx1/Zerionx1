import { mt5BridgeClient } from "@/lib/brokers/mt5-bridge-client";
import { fail, ok } from "@/lib/security/api-response";
import { currentUser } from "@/lib/supabase/rest";
export async function GET(){await currentUser();try{return ok(await mt5BridgeClient.positions())}catch(e){return fail("MT5_POSITIONS_FAILED",e instanceof Error?e.message:"MT5 positions failed",502)}}
