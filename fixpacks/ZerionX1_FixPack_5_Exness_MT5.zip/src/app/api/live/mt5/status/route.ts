import { mt5BridgeClient, mt5BridgeConfigured } from "@/lib/brokers/mt5-bridge-client";
import { fail, ok } from "@/lib/security/api-response";
export async function GET(){if(!mt5BridgeConfigured())return fail("MT5_NOT_CONFIGURED","MT5 bridge is not configured",503);try{return ok(await mt5BridgeClient.health())}catch(e){return fail("MT5_UNAVAILABLE",e instanceof Error?e.message:"MT5 unavailable",502)}}
