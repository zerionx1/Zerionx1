# Zerion X1 FixPack 5 — Exness MT5

Routing: India->Upstox, Crypto->CoinDCX, Forex->Exness MT5. cTrader removed.

Apply:
cd ~/Projects/zerion-x1
rm -rf ~/zxpack5 && mkdir -p ~/zxpack5
unzip -o ~/storage/downloads/ZerionX1_FixPack_5_Exness_MT5.zip -d ~/zxpack5
bash ~/zxpack5/APPLY_FIXPACK_5.sh

Never commit MT5 passwords.
