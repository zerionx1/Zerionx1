#!/usr/bin/env bash
set -euo pipefail
python3 "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/patches/apply.py"
echo "===== CTRADER AUDIT ====="
grep -RniE "ctrader|CTRADER|cTrader" src --exclude-dir=node_modules || true
echo "===== TYPECHECK ====="
npm run typecheck
