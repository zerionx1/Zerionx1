ZERION X1 FIXPACK 8 — CHART + RISK + REALTIME + THEME CLEANUP
Base: b0dc88e or descendant

What this pack changes
1. GoCharting
   - Uses the official UMD URL without forcing anonymous CORS.
   - Uses onReady/onError instead of the old fixed-delay readiness guess.
   - Fixes GoCharting product keys and removes slash-containing chart symbols.
   - Adds required search result keys and richer symbol metadata.
   - Supports historical bars plus Zerion realtime bar/tick subscriptions.
   - Resubscribes after browser visibility/network recovery.
   - Never silently falls back to the old Zerion canvas unless the explicit chart-engine env is set to legacy/canvas/zerion.

2. Four-colour UI
   Canonical runtime colours only:
   #F7F4ED
   #2F2A25
   #3E4A3F
   #E6D8C3

   Removes these legacy global theme overlays from the repo:
   src/app/zerion-premium.css
   src/app/phase-13-premium.css
   src/app/final-prepush.css
   src/app/zerion-luxury-palette.css
   src/app/zerion-luxury-v2.css

   Their needed structural layout rules are migrated into zerion-final-four.css.

3. Trade approval / risk
   - Saved user risk controls remain the sizing source.
   - The old paper 20% notional guard no longer returns raw `risk_limit`.
   - If the default simulation guard is exceeded, Zerion asks for a SECOND explicit confirmation.
   - If the user accepts, paper execution continues with the user's saved risk sizing.
   - Buying-power/broker hard rejections are not bypassed.

4. Continuous scan + feed
   - Background market scan default: ~30 seconds, with overlap protection.
   - Opportunity inbox refreshes every 15 seconds.
   - Each scan invalidates old active setup cards before publishing the current strongest qualified setup.
   - Removes the misleading "Re-check in 14m" countdown; validity and scan cadence are separate.
   - Stops creating repeated market-feed-disconnected notification cards.
   - Filters existing feed-disconnect noise out of the inbox.
   - Realtime socket self-reconnects if an open connection becomes silent.

GoCharting licensing note
This FixPack fixes the integration/load/datafeed contract and does NOT bypass GoCharting licensing. It never injects a demo license into production. If the GoCharting runtime associated with your plan requires a license key, configure NEXT_PUBLIC_GOCHARTING_LICENSE_KEY in Vercel.

Apply from Termux
  unzip ZerionX1_FixPack_8_ChartRiskRealtime.zip -d ~/ZerionX1_FixPack_8
  bash ~/ZerionX1_FixPack_8/APPLY_FIXPACK_8.sh

The script automatically runs:
- git diff --check
- npm run typecheck
- npm test
- npm run build

Do not commit/push until all four checks pass.
