#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

REPO="${1:-$HOME/Projects/zerion-x1}"
PACK_DIR="$(cd "$(dirname "$0")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$HOME/.zerion-fixpack8-backup-$STAMP"

cd "$REPO"

if [ ! -f package.json ] || [ ! -d src ]; then
  echo "ERROR: Zerion X1 repo not found at $REPO"
  exit 1
fi

if ! git merge-base --is-ancestor b0dc88e HEAD >/dev/null 2>&1; then
  echo "ERROR: FixPack 8 expects b0dc88e (or a descendant) as the repo base."
  echo "Current HEAD: $(git rev-parse --short HEAD)"
  exit 1
fi

if [ -n "$(git status --porcelain)" ]; then
  echo "ERROR: Worktree is not clean. Commit/stash current changes first."
  git status --short
  exit 1
fi

echo "===== FIXPACK 8 BACKUP ====="
mkdir -p "$BACKUP"
for f in \
  src/app/globals.css \
  src/app/zerion-final-four.css \
  src/app/zerion-premium.css \
  src/app/phase-13-premium.css \
  src/app/final-prepush.css \
  src/app/zerion-luxury-palette.css \
  src/app/zerion-luxury-v2.css \
  src/components/markets/gocharting-chart-host.tsx \
  src/lib/gocharting/official-datafeed.ts \
  src/components/markets/market-chart-terminal.tsx \
  src/components/alerts/deterministic-market-alert-runtime.tsx \
  src/hooks/use-zerion-market-stream.ts \
  src/app/api/notifications/inbox/route.ts \
  src/components/notifications/agent-opportunity-inbox.tsx \
  src/lib/paper/paper-engine.ts \
  src/lib/execution/opportunity-executor.ts \
  'src/app/api/agents/opportunities/[opportunityId]/approve/route.ts' \
  src/workers/background-ai-loop.ts \
  src/app/api/automation/market-scan/route.ts \
  src/lib/agents/opportunity-store.ts
 do
  if [ -e "$f" ]; then
    mkdir -p "$BACKUP/$(dirname "$f")"
    cp -a "$f" "$BACKUP/$f"
  fi
 done

echo "Backup: $BACKUP"

echo
echo "===== APPLY FIXPACK 8 FILES ====="
cp -a "$PACK_DIR/src/." "$REPO/src/"

# Remove legacy global theme imports that were fighting the canonical four-colour file.
sed -i \
  -e '/@import "\.\/zerion-premium\.css";/d' \
  -e '/@import "\.\/phase-13-premium\.css";/d' \
  -e '/@import "\.\/final-prepush\.css";/d' \
  -e '/@import "\.\/zerion-luxury-palette\.css";/d' \
  -e '/@import "\.\/zerion-luxury-v2\.css";/d' \
  src/app/globals.css

# Their layout-critical rules have been migrated into zerion-final-four.css.
rm -f \
  src/app/zerion-premium.css \
  src/app/phase-13-premium.css \
  src/app/final-prepush.css \
  src/app/zerion-luxury-palette.css \
  src/app/zerion-luxury-v2.css

rm -rf .next

echo
echo "===== THEME CHECK ====="
for f in \
  src/app/zerion-premium.css \
  src/app/phase-13-premium.css \
  src/app/final-prepush.css \
  src/app/zerion-luxury-palette.css \
  src/app/zerion-luxury-v2.css
 do
  if [ -e "$f" ]; then
    echo "ERROR: legacy theme file still exists: $f"
    exit 1
  fi
 done

if grep -Eq '@import "\./(zerion-premium|phase-13-premium|final-prepush|zerion-luxury-palette|zerion-luxury-v2)\.css"' src/app/globals.css; then
  echo "ERROR: legacy theme import still present"
  exit 1
fi

# The canonical theme itself must contain exactly the four approved hex literals.
BAD_COLORS="$(grep -Eo '#[0-9A-Fa-f]{6}' src/app/zerion-final-four.css | tr 'a-f' 'A-F' | sort -u | grep -Ev '^#(F7F4ED|2F2A25|3E4A3F|E6D8C3)$' || true)"
if [ -n "$BAD_COLORS" ]; then
  echo "ERROR: non-approved hex colours found in canonical theme:"
  echo "$BAD_COLORS"
  exit 1
fi

echo "Canonical colours: #F7F4ED #2F2A25 #3E4A3F #E6D8C3"

echo
echo "===== DIFF CHECK ====="
git diff --check

echo
echo "===== TYPECHECK ====="
npm run typecheck

echo
echo "===== TESTS ====="
npm test

echo
echo "===== BUILD ====="
npm run build

echo
echo "===== FINAL STATUS ====="
git status --short

echo
echo "✅ FIXPACK 8 APPLIED + TYPECHECK + TESTS + BUILD PASSED"
echo "Backup kept at: $BACKUP"
