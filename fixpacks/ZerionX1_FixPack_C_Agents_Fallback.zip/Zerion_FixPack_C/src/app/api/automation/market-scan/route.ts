import{fail,ok}from"@/lib/security/api-response";import{runZerionScan}from"@/lib/agents/orchestrator";
function allowed(request:Request){const secret=process.env.CRON_SECRET;if(!secret)return false;return request.headers.get("authorization")===`Bearer ${secret}`}
export async function GET(request:Request){if(!allowed(request))return fail("UNAUTHORIZED","Cron authorization required",401);const raw=process.env.ZERION_SCAN_SYMBOLS??"BTC/USDT,ETH/USDT";const symbols=raw.split(",").map(x=>x.trim()).filter(Boolean);return ok(await runZerionScan(symbols))}
