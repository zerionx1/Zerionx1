#!/data/data/com.termux/files/usr/bin/bash
set -e
ROOT="${1:-$HOME/Projects/zerion-x1}"
cd "$(dirname "$0")"
for f in src/lib/agents/registry.ts src/lib/agents/powerx-client.ts src/lib/agents/deterministic-scanner.ts src/lib/agents/orchestrator.ts src/app/api/agents/status/route.ts src/app/api/automation/market-scan/route.ts; do mkdir -p "$ROOT/$(dirname "$f")"; cp -f "$f" "$ROOT/$f"; done
echo "FixPack C applied. Cron schedule intentionally NOT auto-added; configure only after Vercel plan is confirmed."
