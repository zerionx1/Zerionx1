Zerion X1 FixPack 8.2 — Strict Four-Colour UI + GoCharting Package Runtime

Base required: commit 56e1b2f or newer, clean worktree.

Changes:
- Adds a final strict dashboard CSS layer using only:
  #F7F4ED #2F2A25 #3E4A3F #E6D8C3
- Removes visible dark/wine/amber/rose Tailwind overlays from dashboard surfaces.
- Fixes dark-on-dark page headings and unreadable market/signal/broker text.
- Reworks Home command-center layout for mobile/desktop clarity.
- Reworks Multi-Market Explorer cards/results to semantic four-colour styles.
- Keeps ivory star-field + champagne shooting-star environment.
- Switches GoCharting from the failing hard-coded CDN loader to the official
  @gocharting/chart-sdk package documented by GoCharting.
- Keeps existing Zerion provider datafeed and explicit GoCharting runtime errors.

Apply script installs @gocharting/chart-sdk and updates package.json/package-lock.json.
It does NOT run typecheck/tests/build automatically.
