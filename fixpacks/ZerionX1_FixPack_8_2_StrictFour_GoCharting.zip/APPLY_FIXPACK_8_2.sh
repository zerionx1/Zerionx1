#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

REPO="${1:-$HOME/Projects/zerion-x1}"
PACK_DIR="$(cd "$(dirname "$0")" && pwd)"
BASE_COMMIT="56e1b2f"

cd "$REPO"

echo "===== FIXPACK 8.2 PRECHECK ====="
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "ERROR: $REPO is not a git repository"
  exit 1
fi
if ! git merge-base --is-ancestor "$BASE_COMMIT" HEAD 2>/dev/null; then
  echo "ERROR: FixPack 8.2 requires commit $BASE_COMMIT or newer"
  exit 1
fi
if [ -n "$(git status --porcelain)" ]; then
  echo "ERROR: repository is not clean. Commit/stash current work first."
  git status --short
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$HOME/.zerion-fixpack8-2-backup-$STAMP"
mkdir -p "$BACKUP/src/app" "$BACKUP/src/components/markets" "$BACKUP/src/components/dashboard"

for f in \
  src/app/layout.tsx \
  src/app/zerion-strict-four.css \
  src/components/markets/gocharting-chart-host.tsx \
  src/components/markets/multi-market-explorer.tsx \
  src/components/dashboard/account-command-center.tsx \
  package.json package-lock.json; do
  if [ -f "$f" ]; then
    mkdir -p "$BACKUP/$(dirname "$f")"
    cp -p "$f" "$BACKUP/$f"
  fi
done

echo "Backup: $BACKUP"

echo
echo "===== INSTALL OFFICIAL GOCHARTING PACKAGE ====="
npm install @gocharting/chart-sdk@latest --save

echo
echo "===== APPLY FIXPACK 8.2 FILES ====="
install -D -m 0644 "$PACK_DIR/src/app/layout.tsx" "$REPO/src/app/layout.tsx"
install -D -m 0644 "$PACK_DIR/src/app/zerion-strict-four.css" "$REPO/src/app/zerion-strict-four.css"
install -D -m 0644 "$PACK_DIR/src/components/markets/gocharting-chart-host.tsx" "$REPO/src/components/markets/gocharting-chart-host.tsx"
install -D -m 0644 "$PACK_DIR/src/components/markets/multi-market-explorer.tsx" "$REPO/src/components/markets/multi-market-explorer.tsx"
install -D -m 0644 "$PACK_DIR/src/components/dashboard/account-command-center.tsx" "$REPO/src/components/dashboard/account-command-center.tsx"

echo
echo "===== REQUIRED CHECKS ====="
grep -q "zerion-strict-four.css" src/app/layout.tsx
grep -q 'import("@gocharting/chart-sdk")' src/components/markets/gocharting-chart-host.tsx
grep -q '"@gocharting/chart-sdk"' package.json

COLORS="$(grep -Eoi '#[0-9a-f]{6}' src/app/zerion-strict-four.css | tr '[:lower:]' '[:upper:]' | sort -u | tr '\n' ' ')"
echo "Strict UI hex colours: $COLORS"
BAD="$(grep -Eoi '#[0-9a-f]{6}' src/app/zerion-strict-four.css | tr '[:lower:]' '[:upper:]' | sort -u | grep -Ev '^(#F7F4ED|#2F2A25|#3E4A3F|#E6D8C3)$' || true)"
if [ -n "$BAD" ]; then
  echo "ERROR: non-approved colour found in strict UI CSS"
  echo "$BAD"
  exit 1
fi

git diff --check
rm -rf .next

echo
echo "===== FIXPACK 8.2 APPLIED ====="
git status --short
echo
echo "Next: run npm run typecheck && npm test && npm run build"
