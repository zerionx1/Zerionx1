"use client";

import type { ComponentProps } from "react";
import { useEffect, useId, useMemo, useRef, useState } from "react";

import { ZerionProviderChart } from "@/components/markets/zerion-provider-chart";
import {
  goChartingSymbolKey,
  goChartingZerionDatafeed,
} from "@/lib/gocharting/official-datafeed";

type LegacyProps = ComponentProps<typeof ZerionProviderChart>;
type GoChartInstance = {
  remove?: () => void;
  destroy?: () => void;
  resubscribeAll?: () => void;
};
type CreateChart = (
  target: string | HTMLElement,
  config: Record<string, unknown>,
) => GoChartInstance;
type GoChartingModule = {
  createChart?: CreateChart;
  default?: CreateChart | { createChart?: CreateChart };
};

let sdkLoader: Promise<CreateChart> | null = null;

function errorMessage(error: unknown) {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  return "GoCharting initialization failed";
}

async function loadCreateChart(force = false): Promise<CreateChart> {
  if (force) sdkLoader = null;
  if (sdkLoader) return sdkLoader;

  sdkLoader = import("@gocharting/chart-sdk")
    .then((module) => {
      const sdk = module as unknown as GoChartingModule;
      const candidate =
        sdk.createChart ??
        (typeof sdk.default === "function" ? sdk.default : sdk.default?.createChart);

      if (typeof candidate !== "function") {
        sdkLoader = null;
        throw new Error("GoCharting package loaded but createChart is unavailable");
      }
      return candidate;
    })
    .catch((error) => {
      sdkLoader = null;
      throw error;
    });

  return sdkLoader;
}

function interval(tf: string) {
  return tf === "1h"
    ? "1h"
    : tf === "4h"
      ? "4h"
      : tf === "1d"
        ? "1D"
        : tf === "1w"
          ? "1W"
          : tf;
}

export function GoChartingChartHost(props: LegacyProps) {
  const id = useId();
  const domId = useMemo(() => `zx-gocharting-${id.replaceAll(":", "")}`, [id]);
  const instance = useRef<GoChartInstance | null>(null);
  const observer = useRef<MutationObserver | null>(null);
  const [state, setState] = useState<"idle" | "loading" | "ready" | "error">(
    "idle",
  );
  const [error, setError] = useState("");
  const [retry, setRetry] = useState(0);

  const engine = (
    process.env.NEXT_PUBLIC_ZERION_CHART_ENGINE || "gocharting"
  ).toLowerCase();
  const legacy =
    engine === "legacy" || engine === "canvas" || engine === "zerion";

  useEffect(() => {
    const instrument = props.instrument;
    if (legacy || !instrument) {
      setState("idle");
      return;
    }

    let cancelled = false;
    let readyTimer: ReturnType<typeof setTimeout> | null = null;
    let frame = 0;

    const cleanup = () => {
      if (readyTimer) clearTimeout(readyTimer);
      if (frame) cancelAnimationFrame(frame);
      observer.current?.disconnect();
      observer.current = null;
      try {
        instance.current?.remove?.();
        instance.current?.destroy?.();
      } catch {
        // Navigation cleanup must not block the page.
      }
      instance.current = null;
    };

    const markReady = () => {
      if (cancelled) return;
      if (readyTimer) clearTimeout(readyTimer);
      readyTimer = null;
      setState("ready");
    };

    void (async () => {
      setState("loading");
      setError("");
      cleanup();

      try {
        const createChart = await loadCreateChart(retry > 0);
        if (cancelled) return;

        const host = document.getElementById(domId);
        if (!host) throw new Error("GoCharting chart container is unavailable");

        observer.current = new MutationObserver(() => {
          if (host.childElementCount > 0) markReady();
        });
        observer.current.observe(host, { childList: true, subtree: true });

        const licenseKey =
          process.env.NEXT_PUBLIC_GOCHARTING_LICENSE_KEY?.trim();
        const config: Record<string, unknown> = {
          symbol: goChartingSymbolKey(instrument),
          interval: interval(props.timeframe),
          datafeed: goChartingZerionDatafeed,
          autosize: true,
          theme: "light",
          debugLog: false,
          onReady: markReady,
          onError: (value: unknown) => {
            if (cancelled) return;
            setError(errorMessage(value));
            setState("error");
          },
        };
        if (licenseKey) config.licenseKey = licenseKey;

        instance.current = createChart(`#${domId}`, config);

        frame = requestAnimationFrame(() => {
          if (host.childElementCount > 0) markReady();
        });

        readyTimer = setTimeout(() => {
          if (cancelled || state === "ready") return;
          if (host.childElementCount > 0) {
            markReady();
            return;
          }
          setError(
            "GoCharting package loaded, but the chart did not render. Check the browser console for the exact SDK or license error.",
          );
          setState("error");
        }, 15_000);
      } catch (value) {
        console.error("GoCharting initialization failed", value);
        if (!cancelled) {
          setError(errorMessage(value));
          setState("error");
        }
      }
    })();

    return () => {
      cancelled = true;
      cleanup();
    };
  }, [domId, legacy, props.instrument, props.timeframe, retry]);

  useEffect(() => {
    if (legacy) return;
    const resubscribe = () => {
      if (!document.hidden) instance.current?.resubscribeAll?.();
    };
    window.addEventListener("online", resubscribe);
    document.addEventListener("visibilitychange", resubscribe);
    return () => {
      window.removeEventListener("online", resubscribe);
      document.removeEventListener("visibilitychange", resubscribe);
    };
  }, [legacy]);

  if (legacy) return <ZerionProviderChart {...props} />;

  if (!props.instrument) {
    return (
      <div className="zx-gc-error">
        <div>
          <strong>Select an instrument</strong>
          <p>Choose a provider-backed symbol to open the GoCharting workspace.</p>
        </div>
      </div>
    );
  }

  if (state === "error") {
    return (
      <div className="zx-gc-error" style={{ minHeight: props.height }}>
        <div>
          <strong>GoCharting could not start</strong>
          <p>{error}</p>
          <button
            type="button"
            onClick={() => {
              sdkLoader = null;
              setRetry((value) => value + 1);
            }}
          >
            Retry GoCharting
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="zx-gocharting-runtime" style={{ minHeight: props.height }}>
      <div
        className={
          state === "loading" ? "zx-gc-loader is-loading" : "zx-gc-loader"
        }
        aria-hidden={state !== "loading"}
      >
        <div className="zx-gc-loader-grid" />
        <div className="zx-gc-loader-bar" />
        <div className="zx-gc-loader-bar short" />
      </div>
      <div
        id={domId}
        className={state === "ready" ? "zx-gc-canvas is-ready" : "zx-gc-canvas"}
        style={{ minHeight: props.height }}
      />
      {state === "ready" ? (
        <div className="zx-gc-attribution">Powered by GoCharting</div>
      ) : null}
    </div>
  );
}
