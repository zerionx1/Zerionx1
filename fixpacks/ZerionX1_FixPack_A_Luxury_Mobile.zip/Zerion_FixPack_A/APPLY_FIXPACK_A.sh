#!/data/data/com.termux/files/usr/bin/bash
set -e
ROOT="${1:-$HOME/Projects/zerion-x1}"
cd "$(dirname "$0")"
cp -f src/app/zerion-luxury-v2.css "$ROOT/src/app/zerion-luxury-v2.css"
cp -f src/components/dashboard/sidebar.tsx "$ROOT/src/components/dashboard/sidebar.tsx"
cp -f src/components/dashboard/shell.tsx "$ROOT/src/components/dashboard/shell.tsx"
cp -f src/components/navigation/mobile-bottom-nav.tsx "$ROOT/src/components/navigation/mobile-bottom-nav.tsx"
cp -f src/components/journal/trade-journal.tsx "$ROOT/src/components/journal/trade-journal.tsx"
python - "$ROOT/src/app/globals.css" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text(); line='@import "./zerion-luxury-v2.css";\n'
if line not in s:
    anchor='@import "./payment-upgrade-flow.css";\n'
    s=s.replace(anchor,anchor+line) if anchor in s else line+s
    p.write_text(s)
PY
echo "FixPack A applied. Run npm run typecheck."
