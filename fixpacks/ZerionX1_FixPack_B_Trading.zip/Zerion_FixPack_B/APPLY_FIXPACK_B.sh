#!/data/data/com.termux/files/usr/bin/bash
set -e
ROOT="${1:-$HOME/Projects/zerion-x1}"
cd "$(dirname "$0")"
for f in \
 src/components/markets/market-chart-terminal.tsx \
 src/components/markets/tradingview-advanced-chart.tsx \
 src/app/api/paper/positions/close/route.ts \
 src/lib/paper/paper-store.ts \
 src/components/strategies/strategy-template-gallery.tsx \
 src/app/api/strategies/route.ts \
 src/app/trading-workspace-v2.css; do mkdir -p "$ROOT/$(dirname "$f")"; cp -f "$f" "$ROOT/$f"; done
python - "$ROOT/src/app/globals.css" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text();line='@import "./trading-workspace-v2.css";\n'
if line not in s:
 anchor='@import "./zerion-luxury-v2.css";\n'
 s=s.replace(anchor,anchor+line) if anchor in s else line+s;p.write_text(s)
PY
echo "FixPack B applied. Run npm run typecheck."
