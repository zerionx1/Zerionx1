from __future__ import annotations

import json
import os
import sys
from typing import Any

import MetaTrader5 as mt5

TERMINAL_PATH = os.getenv("MT5_TERMINAL_PATH", "").strip() or None

class WorkerError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(detail)
        self.status = status
        self.detail = detail

def asdict(value: Any) -> dict[str, Any]:
    if hasattr(value, "_asdict"):
        return dict(value._asdict())
    return dict(value)

def fail(status: int, detail: str):
    raise WorkerError(status, detail)

def connect(credentials: dict[str, Any]):
    try:
        login = int(str(credentials["login"]))
        password = str(credentials["password"])
        server = str(credentials["server"])
    except Exception:
        fail(400, "Invalid MT5 credentials")
    kwargs = {"login": login, "password": password, "server": server, "timeout": 30000, "portable": True}
    ok = mt5.initialize(TERMINAL_PATH, **kwargs) if TERMINAL_PATH else mt5.initialize(**kwargs)
    if not ok:
        fail(401, f"MT5 login failed: {mt5.last_error()}")
    info = mt5.account_info()
    if info is None:
        fail(401, f"MT5 account_info failed after login: {mt5.last_error()}")
    return info

def ensure_symbol(symbol: str) -> None:
    info = mt5.symbol_info(symbol)
    if info is None:
        fail(404, f"MT5 symbol not found: {symbol}")
    if not info.visible and not mt5.symbol_select(symbol, True):
        fail(409, f"Could not enable MT5 symbol: {symbol}")

def filling_mode(symbol: str) -> int:
    info = mt5.symbol_info(symbol)
    mode = getattr(info, "filling_mode", None) if info else None
    if mode in (mt5.ORDER_FILLING_FOK, mt5.ORDER_FILLING_IOC, mt5.ORDER_FILLING_RETURN):
        return int(mode)
    return mt5.ORDER_FILLING_IOC

def build_order(order: dict[str, Any]) -> dict[str, Any]:
    symbol = str(order["symbol"])
    side = str(order["side"]).lower()
    volume = float(order["volume"])
    if side not in {"buy", "sell"}: fail(400, "side must be buy or sell")
    if volume <= 0 or volume > 100: fail(400, "Invalid order volume")
    ensure_symbol(symbol)
    tick = mt5.symbol_info_tick(symbol)
    if tick is None: fail(503, f"No MT5 tick for {symbol}")
    buy = side == "buy"
    price = tick.ask if buy else tick.bid
    sl = order.get("stop_loss")
    tp = order.get("take_profit")
    if sl is not None:
        sl = float(sl)
        if (buy and sl >= price) or ((not buy) and sl <= price): fail(400, "Invalid stop loss for current market side")
    if tp is not None:
        tp = float(tp)
        if (buy and tp <= price) or ((not buy) and tp >= price): fail(400, "Invalid take profit for current market side")
    return {"action": mt5.TRADE_ACTION_DEAL,"symbol": symbol,"volume": volume,"type": mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL,"price": price,"sl": sl or 0.0,"tp": tp or 0.0,"deviation": int(order.get("deviation", 20)),"magic": 510001,"comment": str(order.get("comment", "Zerion X1"))[:31],"type_time": mt5.ORDER_TIME_GTC,"type_filling": filling_mode(symbol)}

def handle(payload: dict[str, Any]) -> tuple[dict[str, Any], int]:
    operation = str(payload.get("operation", ""))
    credentials = payload.get("credentials")
    if not isinstance(credentials, dict): fail(400, "credentials are required")
    environment = str(credentials.get("environment", "demo"))
    try:
        info = connect(credentials)
        if operation == "verify": return {"ok": True,"login": info.login,"server": info.server,"currency": info.currency,"environment": environment}, 200
        if operation == "account":
            result = asdict(info); result["environment"] = environment; result["ok"] = True; return result, 200
        if operation == "positions":
            rows = mt5.positions_get() or []; return {"ok": True,"count": len(rows),"positions": [asdict(row) for row in rows]}, 200
        if operation == "order_place":
            order = payload.get("order")
            if not isinstance(order, dict): fail(400, "order is required")
            request = build_order(order); checked = mt5.order_check(request)
            if checked is None: fail(409, f"MT5 order_check failed: {mt5.last_error()}")
            if getattr(checked, "retcode", 0) not in (0, mt5.TRADE_RETCODE_DONE):
                comment = getattr(checked, "comment", "order_check rejected")
                fail(409, f"MT5 order_check rejected: {comment}")
            result = mt5.order_send(request)
            if result is None: fail(503, f"MT5 order_send failed: {mt5.last_error()}")
            data = asdict(result); data["ok"] = result.retcode == mt5.TRADE_RETCODE_DONE; data["environment"] = environment
            return data, 200 if data["ok"] else 409
        if operation == "order_modify":
            item = payload.get("modification")
            if not isinstance(item, dict): fail(400, "modification is required")
            ticket = int(item["ticket"]); positions = mt5.positions_get(ticket=ticket) or []
            if not positions: fail(404, "MT5 position not found")
            pos = positions[0]; request = {"action": mt5.TRADE_ACTION_SLTP,"position": ticket,"symbol": pos.symbol,"sl": float(item.get("stop_loss") or 0.0),"tp": float(item.get("take_profit") or 0.0),"magic": 510001}
            result = mt5.order_send(request)
            if result is None: fail(503, f"MT5 modify failed: {mt5.last_error()}")
            data = asdict(result); data["ok"] = result.retcode == mt5.TRADE_RETCODE_DONE; return data, 200 if data["ok"] else 409
        if operation == "order_close":
            item = payload.get("close")
            if not isinstance(item, dict): fail(400, "close is required")
            ticket = int(item["ticket"]); positions = mt5.positions_get(ticket=ticket) or []
            if not positions: fail(404, "MT5 position not found")
            pos = positions[0]; tick = mt5.symbol_info_tick(pos.symbol)
            if tick is None: fail(503, "No live tick for MT5 position")
            is_buy = pos.type == mt5.POSITION_TYPE_BUY
            request = {"action": mt5.TRADE_ACTION_DEAL,"position": ticket,"symbol": pos.symbol,"volume": float(item.get("volume") or pos.volume),"type": mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY,"price": tick.bid if is_buy else tick.ask,"deviation": int(item.get("deviation", 20)),"magic": 510001,"comment": "Zerion X1 close","type_time": mt5.ORDER_TIME_GTC,"type_filling": filling_mode(pos.symbol)}
            result = mt5.order_send(request)
            if result is None: fail(503, f"MT5 close failed: {mt5.last_error()}")
            data = asdict(result); data["ok"] = result.retcode == mt5.TRADE_RETCODE_DONE; return data, 200 if data["ok"] else 409
        fail(400, f"Unsupported MT5 operation: {operation}")
    finally:
        try: mt5.shutdown()
        except Exception: pass

def response(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        data, status = handle(payload); data["_status"] = status; return data
    except WorkerError as exc:
        return {"ok": False, "detail": exc.detail, "_status": exc.status}
    except Exception as exc:
        return {"ok": False, "detail": f"MT5 worker exception: {type(exc).__name__}: {exc}", "_status": 500}

def daemon() -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line: continue
        try: payload = json.loads(line)
        except Exception: payload = None
        result = response(payload if isinstance(payload, dict) else {})
        print(json.dumps(result, separators=(",", ":"), ensure_ascii=False), flush=True)

def main() -> None:
    if "--daemon" in sys.argv:
        daemon(); return
    try: payload = json.load(sys.stdin)
    except Exception: payload = {}
    print(json.dumps(response(payload), separators=(",", ":"), ensure_ascii=False), flush=True)

if __name__ == "__main__": main()
