# Zerion X1 FixPack 6 — Complete Production Repair

Base reviewed: GitHub `zerionx1/Zerionx1` main at `e73c285`.

## Included repairs
- Four-colour UI lock: `#F7F4ED`, `#2F2A25`, `#3E4A3F`, `#E6D8C3`.
- Removes the olive/mehndi page wash through a final, last-loaded CSS override.
- Mobile bottom bar becomes Home / Markets / Charts / Positions / More.
- Adds a unified Paper + Real Positions page and moves AI back to the full menu.
- GoCharting is the default chart engine. The old canvas chart is used only if `NEXT_PUBLIC_ZERION_CHART_ENGINE=legacy|canvas|zerion` is explicitly set. A GoCharting load failure is shown instead of silently switching charts.
- Rebuilds deterministic opportunity logic with symmetric LONG/SHORT scoring, NO TRADE for weak structure, 70% confidence gate, support/resistance, and strict minimum 1:3 R:R.
- Persists only the single strongest qualified setup per scan and deduplicates near-identical setups.
- Notification inbox now reads the nested trade plan correctly, so Entry / SL / Target / Support / Resistance / R:R are no longer blank.
- Removes the strategy deployment selector from opportunity approval. User chooses Paper or Real once; approval creates a locked trade proposal with broker routing metadata.
- Realtime feed handling uses reconnect hysteresis and only emits a feed-outage notification after a sustained 45-second outage.
- Supabase browser auth explicitly persists sessions and auto-refreshes tokens.
- Dynamic trailing runtime: approved setups can auto-move paper/MT5 stops after favourable structure movement when Auto trailing is enabled; otherwise a trailing-stop notification is emitted. Upstox/CoinDCX fall back to notification until a provider-native stop-modification order id is available.
- MT5 worker changes from spawning a new Wine+Python process on every request to one persistent Windows-Python executor, reducing the 512 MB request-time memory spike. MT5 errors are returned with useful detail.
- MT5 order filling mode is derived from the symbol instead of forcing IOC for every symbol.

## Important runtime note
The MT5 change is a real runtime architecture change and must be redeployed to the Render MT5 worker. It still needs a demo-account verification after deployment; a code patch cannot prove Exness login/runtime success without the live Render process.

## Apply
Run `bash APPLY_FIXPACK_6_COMPLETE.sh` from the extracted pack. It defaults to `~/Projects/zerion-x1`.

The script backs up overwritten files, applies the pack, runs Python syntax checks, then runs Zerion typecheck/tests/build. It does not commit or push automatically.
