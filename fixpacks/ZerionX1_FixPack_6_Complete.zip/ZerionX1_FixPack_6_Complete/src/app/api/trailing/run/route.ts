import { currentUser, select, update } from "@/lib/supabase/rest";
import { ok, fail } from "@/lib/security/api-response";
import { quoteStore } from "@/lib/market/quote-store";
import { emitUserNotification } from "@/lib/notifications/notification-events";
import { getConnectedMt5Credentials } from "@/lib/brokers/connection-store";
import { mt5BridgeClient } from "@/lib/brokers/mt5-bridge-client";

type Row=Record<string,unknown>;
const rec=(v:unknown)=>v&&typeof v==="object"&&!Array.isArray(v)?v as Row:{};
const num=(v:unknown)=>{const n=Number(v);return Number.isFinite(n)?n:0};

export async function POST(){
  try{
    const user=await currentUser();
    const proposals=await select("trade_proposals",`owner_id=eq.${user.id}&status=eq.approved-ready&order=created_at.desc&limit=20`);
    const actions:Row[]=[];
    for(const proposal of proposals){
      const order=rec(proposal.order_payload),trailing=rec(order.trailing),symbol=String(order.symbol??proposal.symbol??"");
      const side=String(order.side??"").toLowerCase(),entry=num(order.entry),initialStop=num(order.stopLoss),target=num(order.takeProfit),lastStop=num(order.trailingLastStop)||initialStop;
      if(!symbol||!entry||!initialStop||!target||!trailing.enabled)continue;
      const risk=Math.abs(entry-initialStop);if(!risk)continue;
      let current=0,ticket=0;
      const broker=String(proposal.broker_key??"");
      if(broker==="exness-mt5"){
        try{const creds=await getConnectedMt5Credentials();const envelope=await mt5BridgeClient.positions(creds) as Row;const rows=Array.isArray(envelope.positions)?envelope.positions as Row[]:[];const hit=rows.find(r=>String(r.symbol??"").toUpperCase()===symbol.toUpperCase());if(hit){current=num(hit.price_current);ticket=num(hit.ticket)}}catch{}
      }
      if(!current){const quote=await quoteStore.get(symbol).catch(()=>null);current=num(quote?.price)}
      if(!current)continue;
      const triggered=side==="buy"?current>=entry+risk*1.5:side==="sell"?current<=entry-risk*1.5:false;
      if(!triggered)continue;
      const candidate=side==="buy"?Math.max(entry+risk*.5,current-risk*.65):Math.min(entry-risk*.5,current+risk*.65);
      const improves=side==="buy"?candidate>lastStop:candidate<lastStop;if(!improves)continue;
      const nextStop=Number(candidate.toFixed(current<100?4:2)),auto=order.autoTrailing===true;
      let modified=false;
      if(auto&&broker==="exness-mt5"&&ticket){
        const creds=await getConnectedMt5Credentials();await mt5BridgeClient.orderModify(creds,{ticket,stop_loss:nextStop,take_profit:target});modified=true;
      }
      if(auto&&String(proposal.mode)==="paper"){
        const positions=await select("paper_positions",`owner_id=eq.${user.id}&symbol=eq.${encodeURIComponent(symbol)}&quantity=neq.0&limit=1`);const pos=positions[0];if(pos){await update("paper_positions",`owner_id=eq.${user.id}&id=eq.${String(pos.id)}`,{stop_loss:nextStop,updated_at:new Date().toISOString()});modified=true;}
      }
      if(!modified){await emitUserNotification({kind:"trailing-stop-suggestion",title:`${symbol} trailing SL ready`,body:`Market structure moved in favour. Suggested SL: ${nextStop}.`,priority:"high",eventKey:`trailing-${proposal.id}-${nextStop}`,actionUrl:"/dashboard/positions",data:{proposalId:proposal.id,symbol,side,current,nextStop,autoTrailing:auto}});}
      await update("trade_proposals",`owner_id=eq.${user.id}&id=eq.${String(proposal.id)}`,{order_payload:{...order,trailingLastStop:nextStop},updated_at:new Date().toISOString()});
      actions.push({proposalId:proposal.id,symbol,current,nextStop,modified,broker});
    }
    return ok({checked:proposals.length,actions});
  }catch(error){return fail("TRAILING_EVALUATION_FAILED",error instanceof Error?error.message:"Unable to evaluate trailing stops",400);}
}
