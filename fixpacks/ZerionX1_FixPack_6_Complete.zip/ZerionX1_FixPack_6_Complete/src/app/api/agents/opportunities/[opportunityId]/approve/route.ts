import { currentUser, insert, select } from "@/lib/supabase/rest";
import { fail, ok } from "@/lib/security/api-response";

function record(v:unknown){return v&&typeof v==="object"&&!Array.isArray(v)?v as Record<string,unknown>:{};}
function brokerFor(market:string){return market==="crypto"?"coindcx":market==="forex"?"exness-mt5":"upstox";}

export async function POST(request:Request,context:{params:Promise<{opportunityId:string}>}){
  try{
    const user=await currentUser(),{opportunityId}=await context.params;
    const body=await request.json().catch(()=>null) as {confirmed?:boolean;mode?:"paper"|"live";autoTrailing?:boolean}|null;
    if(body?.confirmed!==true||!body.mode)return fail("CONFIRMATION_REQUIRED","Explicit Paper or Real confirmation is required",400);
    const opportunity=(await select("agent_opportunities",`id=eq.${encodeURIComponent(opportunityId)}&status=eq.active&limit=1`))[0];
    if(!opportunity)return fail("OPPORTUNITY_NOT_FOUND","Opportunity not found or no longer active",404);
    const expiresAt=Date.parse(String(opportunity.expires_at??""));if(!Number.isFinite(expiresAt)||expiresAt<=Date.now())return fail("OPPORTUNITY_EXPIRED","This opportunity expired. Refresh for a fresh setup.",410);
    const analysis=record(opportunity.analysis),plan=record(analysis.tradePlan),targets=Array.isArray(plan.targets)?plan.targets:[];
    if(Number(opportunity.confidence)<70||Number(plan.riskReward)<3||!plan.entry||!plan.stopLoss||!targets[0])return fail("SETUP_NOT_QUALIFIED","Trade no longer meets Zerion's 70% confidence and minimum 1:3 risk/reward gate",422);
    const market=String(opportunity.market??"india"),broker=body.mode==="paper"?"paper":brokerFor(market),now=new Date().toISOString();
    const proposals=await insert<Record<string,unknown>>("trade_proposals",{owner_id:user.id,broker_key:broker,strategy_id:null,mode:body.mode,status:"approved-ready",symbol:opportunity.symbol,order_payload:{opportunityId,symbol:opportunity.symbol,market,side:plan.side,entry:plan.entry,stopLoss:plan.stopLoss,takeProfit:targets[0],riskReward:plan.riskReward,support:plan.support??null,resistance:plan.resistance??null,trailing:plan.trailing??null,autoTrailing:body.autoTrailing===true,trailingLastStop:plan.stopLoss??null,quantity:null},rationale:[String(opportunity.reason)],confidence:opportunity.confidence,confirmed_at:now,expires_at:opportunity.expires_at,created_at:now,updated_at:now});
    const nextUrl=body.mode==="paper"?`/dashboard/paper?opportunity=${encodeURIComponent(opportunityId)}`:`/dashboard/live-trading?opportunity=${encodeURIComponent(opportunityId)}`;
    return ok({proposal:proposals[0],executionStarted:false,nextAction:{url:nextUrl,mode:body.mode,broker},message:`${body.mode==="paper"?"Paper":"Real"} trade plan approved and locked. Entry, SL, 1:3 target and trailing rules are ready without a deployment selector.`},201);
  }catch(error){return fail("OPPORTUNITY_APPROVAL_FAILED",error instanceof Error?error.message:"Unable to approve opportunity",400);}
}
