"use client";
import { useEffect } from "react";

export function DynamicTrailingRuntime(){
  useEffect(()=>{
    let stopped=false;
    const run=async()=>{if(stopped||document.visibilityState!=="visible")return;await fetch("/api/trailing/run",{method:"POST",cache:"no-store"}).catch(()=>{})};
    void run();
    const timer=window.setInterval(()=>void run(),15000);
    return()=>{stopped=true;window.clearInterval(timer)};
  },[]);
  return null;
}
