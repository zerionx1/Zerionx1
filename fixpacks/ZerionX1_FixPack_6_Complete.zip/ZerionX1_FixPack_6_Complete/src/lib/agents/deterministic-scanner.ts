import "server-only";

import { quoteStore } from "@/lib/market/quote-store";

export type ScanDirection = "long-watch" | "short-watch" | "neutral";
export type OpportunityTradePlan = {
  side: "buy" | "sell" | "none";
  entry: number | null;
  stopLoss: number | null;
  targets: number[];
  support: number | null;
  resistance: number | null;
  trailing: { enabled: boolean; trigger: number | null; distance: number | null; rule?: string };
  riskReward: number | null;
  maxLossPercent: number | null;
  maxProfitPercent: number | null;
  validityMinutes: number;
  invalidation: string;
};
export type ScanOpportunity = {
  symbol: string; price: number; direction: ScanDirection; confidence: number; reason: string; source: string;
  requiresUserApproval: true; tradePlan: OpportunityTradePlan;
};

function round(value:number,price:number){const d=price<1?6:price<100?4:2;return Number(value.toFixed(d));}
function clamp(v:number,min:number,max:number){return Math.max(min,Math.min(max,v));}
function neutralPlan():OpportunityTradePlan{return {side:"none",entry:null,stopLoss:null,targets:[],support:null,resistance:null,trailing:{enabled:false,trigger:null,distance:null},riskReward:null,maxLossPercent:null,maxProfitPercent:null,validityMinutes:10,invalidation:"No qualified directional setup."};}

export async function deterministicMarketScan(symbols:string[]):Promise<ScanOpportunity[]>{
  const quotes=await quoteStore.list(symbols);
  return quotes.map((q):ScanOpportunity=>{
    const price=Number(q.price),open=Number(q.open||price),high=Number(q.high||price),low=Number(q.low||price),prev=Number(q.previousClose||price),sessionPct=Number(q.changePercent||0);
    const range=Math.max(high-low,price*.0015),rangePct=range/Math.max(price,1e-9)*100;
    const pos=range>0?clamp((price-low)/range,0,1):.5;
    const fromOpen=((price-open)/Math.max(open,1e-9))*100,fromPrev=((price-prev)/Math.max(prev,1e-9))*100;
    let score=0;
    score+=clamp(sessionPct,-3,3)*1.45;
    score+=clamp(fromOpen,-2,2)*1.2;
    score+=clamp(fromPrev,-2,2)*.9;
    score+=(pos-.5)*4.4;
    const threshold=clamp(rangePct*.55,1.25,2.5);
    const direction:ScanDirection=score>=threshold?"long-watch":score<=-threshold?"short-watch":"neutral";
    const strength=Math.abs(score);
    const confidence=direction==="neutral"?Math.min(69,Math.round(44+strength*4)):clamp(Math.round(64+Math.min(16,strength*3.6)+Math.min(8,Math.abs(sessionPct)*1.4)),70,88);
    if(direction==="neutral"||confidence<70)return {symbol:q.symbol,price,direction:"neutral",confidence,reason:"NO TRADE: momentum, session location and open/previous-close confirmation are not aligned strongly enough.",source:q.source,requiresUserApproval:true as const,tradePlan:neutralPlan()};

    const isLong=direction==="long-watch";
    const support=low+range*.16,resistance=high-range*.16;
    const minRisk=price*clamp(rangePct*.28,.30,1.20)/100;
    const structureStop=isLong?support:resistance;
    let stop=isLong?Math.min(structureStop,price-minRisk):Math.max(structureStop,price+minRisk);
    let risk=Math.abs(price-stop);
    const maxRisk=price*.018;
    if(risk>maxRisk){risk=maxRisk;stop=isLong?price-risk:price+risk;}
    if(risk<=0){return {symbol:q.symbol,price,direction:"neutral",confidence:59,reason:"NO TRADE: invalid market structure for a controlled stop.",source:q.source,requiresUserApproval:true as const,tradePlan:neutralPlan()};}
    const target=isLong?price+risk*3:price-risk*3;
    const riskPct=risk/price*100;
    const trailingTrigger=isLong?price+risk*1.5:price-risk*1.5;
    const reasonBits=[`${sessionPct>=0?"+":""}${sessionPct.toFixed(2)}% session`,`${fromOpen>=0?"+":""}${fromOpen.toFixed(2)}% vs open`,`${Math.round(pos*100)}% of session range`,`strict 1:3 R:R`];
    return {symbol:q.symbol,price,direction,confidence,reason:`${isLong?"Bullish":"Bearish"} qualified setup: ${reasonBits.join(" · ")}.`,source:q.source,requiresUserApproval:true as const,tradePlan:{side:isLong?"buy":"sell",entry:round(price,price),stopLoss:round(stop,price),targets:[round(target,price)],support:round(support,price),resistance:round(resistance,price),trailing:{enabled:true,trigger:round(trailingTrigger,price),distance:round(risk*.65,price),rule:"Trail only after structure confirms in favour; if auto-trailing is off, notify the user before moving SL."},riskReward:3,maxLossPercent:Number(riskPct.toFixed(2)),maxProfitPercent:Number((riskPct*3).toFixed(2)),validityMinutes:strength>=4.5?15:strength>=3.2?22:30,invalidation:isLong?"Invalidate if price loses support/stop or bullish structure fails.":"Invalidate if price clears resistance/stop or bearish structure fails."}};
  }).sort((a,b)=>{if(a.direction==="neutral"&&b.direction!=="neutral")return 1;if(b.direction==="neutral"&&a.direction!=="neutral")return -1;return b.confidence-a.confidence;});
}
