import "server-only";
import { adminInsert } from "@/lib/supabase/admin-rest";
import type { ZerionScanResult } from "./types";

function inferMarket(symbol:string){const s=symbol.toUpperCase();if(s.includes("USDT")||s.includes("USDC")||s.includes("BTC")||s.includes("ETH")||s.includes("SOL"))return "crypto";if(s.includes("XAU")||s.includes("XAG")||/^(EUR|GBP|USD|JPY|AUD|NZD|CAD|CHF)[/-]?(EUR|GBP|USD|JPY|AUD|NZD|CAD|CHF)$/.test(s.replaceAll(" ","")))return "forex";return "india";}
function directionCode(direction:string){return direction==="long-watch"?"L":direction==="short-watch"?"S":"N";}
function level(v:unknown){const n=Number(v);return Number.isFinite(n)?n.toPrecision(6):"na";}

export async function persistScanOpportunities(result:ZerionScanResult){
  // Only the single strongest qualified setup is surfaced per scan. This removes 3-4 near-identical cards and overtrading pressure.
  const candidate=result.candidates.filter(c=>c.direction!=="neutral"&&c.confidence>=70&&c.tradePlan.entry&&c.tradePlan.stopLoss&&c.tradePlan.targets.length>=1&&Number(c.tradePlan.riskReward)>=3).sort((a,b)=>b.confidence-a.confidence)[0];
  if(!candidate)return [];
  const generatedAt=new Date(result.scannedAt),expires=new Date(generatedAt.getTime()+candidate.tradePlan.validityMinutes*60_000).toISOString();
  const bucket=Math.floor(generatedAt.getTime()/(20*60_000));
  const fingerprint=[bucket,candidate.symbol,directionCode(candidate.direction),level(candidate.tradePlan.entry),level(candidate.tradePlan.stopLoss),level(candidate.tradePlan.targets[0])].join(":");
  const row={fingerprint,symbol:candidate.symbol,market:inferMarket(candidate.symbol),price:candidate.price,direction:candidate.direction,confidence:candidate.confidence,reason:candidate.reason,source:candidate.source,mode:result.mode,analysis:{stages:result.stages,tradePlan:candidate.tradePlan,antiOvertrading:{oneBestSetupPerScan:true,fingerprintBucketMinutes:20,minimumConfidence:70,minimumRiskReward:3,neutralSignalsPersisted:false}},status:"active",requires_user_approval:true,generated_at:result.scannedAt,expires_at:expires};
  return adminInsert<Record<string,unknown>>("agent_opportunities?on_conflict=fingerprint",[row],"resolution=merge-duplicates,return=representation");
}
