#!/usr/bin/env bash
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="${1:-$HOME/Projects/zerion-x1}"

if [ ! -d "$REPO/.git" ]; then
  echo "ERROR: Zerion repo not found at $REPO"
  exit 1
fi

cd "$REPO"
HEAD="$(git rev-parse HEAD)"
echo "===== ZERION FIXPACK 6 ====="
echo "Repo: $REPO"
echo "Current HEAD: $HEAD"

echo "===== WORKTREE CHECK ====="
git status --short

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$REPO/.fixpack6-backup-$STAMP"
mkdir -p "$BACKUP"

for top in src mt5-bridge; do
  [ -d "$PACK_DIR/$top" ] || continue
  while IFS= read -r -d '' source; do
    rel="${source#$PACK_DIR/}"
    target="$REPO/$rel"
    if [ -f "$target" ]; then
      mkdir -p "$BACKUP/$(dirname "$rel")"
      cp -p "$target" "$BACKUP/$rel"
    fi
  done < <(find "$PACK_DIR/$top" -type f -print0)
done

echo "Backup: $BACKUP"

for top in src mt5-bridge; do
  [ -d "$PACK_DIR/$top" ] || continue
  cp -a "$PACK_DIR/$top/." "$REPO/$top/"
done

echo "===== PYTHON CHECK ====="
python3 -m py_compile mt5-bridge/app/worker_server.py mt5-bridge/app/worker_exec.py

echo "===== GIT DIFF CHECK ====="
git diff --check

echo "===== TYPECHECK ====="
npm run typecheck

echo "===== TESTS ====="
npm run test

echo "===== BUILD ====="
npm run build

echo "===== COMPLETE ====="
echo "FixPack 6 applied and local checks completed."
echo "Nothing was committed or pushed automatically."
