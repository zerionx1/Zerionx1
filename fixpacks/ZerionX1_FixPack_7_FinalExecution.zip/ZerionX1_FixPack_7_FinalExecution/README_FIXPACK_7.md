# Zerion X1 FixPack 7 — Final Execution + Dynamic Trailing + Signal Validation

Base commit expected: `e73c285`

This ZIP includes FixPack 6 and the additional fixes requested after the first review.

## What this pack changes

### 1. Approve now means execute
- Removes the old deployment-selection requirement.
- Paper approval risk-sizes and fills the paper order with SL + 1:3 target.
- Upstox live approval places a multi-leg GTT with ENTRY + TARGET + STOPLOSS.
- Upstox auto-trailing uses the broker-native GTT `trailing_gap` when enabled.
- CoinDCX live approval uses a leverage-1 margin/bracket request with stop, target and provider trailing when enabled.
- Exness MT5 live approval sends the order directly through the MT5 gateway/worker.
- MT5 volume can be automatically calculated from the user's risk budget and stop distance.
- Successful approval redirects to unified Positions, not a deployment page.

### 2. Dynamic trailing is market-behaviour driven
- Removes the fixed 15-second trailing timer.
- Dashboard runtime re-evaluates trailing on actual provider quote changes.
- Paper positions update SL automatically when auto-trailing is enabled.
- MT5 worker keeps a warm Python process and an in-process market watcher for approved MT5 auto-trailing.
- Upstox and CoinDCX use provider-native trailing where the order type supports it.
- When auto-trailing is OFF, Zerion emits a notification instead of silently moving SL.

### 3. MT5 502 architecture repair
- Keeps one warm Windows Python/MetaTrader5 executor instead of importing MetaTrader5 in a new Windows process for every API request.
- Adds direct risk-based lot sizing using `mt5.order_calc_profit` and symbol volume limits.
- Keeps detailed MT5 errors instead of collapsing everything into a generic 502.
- Gateway order model accepts `risk_budget` as an alternative to manually supplied volume.
- Adds MT5 market-behaviour trailing to the warm worker.

Production still must be verified with a demo MT5 login after Render redeploy. A ZIP cannot prove broker credentials/network acceptance before deployment.

### 4. No fake 70–80% accuracy claim
- Scanner now requires at least 3 aligned directional factors.
- Minimum setup quality: 74.
- Minimum surfaced confidence: 70.
- Minimum R:R: 1:3.
- Still surfaces only one strongest setup at a time.
- Adds `signal_outcomes` persistence for measured wins/losses.
- Once 20 directional outcomes are collected, publishing is blocked if observed win rate is below 70%.
- Until enough outcomes exist, the system is explicitly in calibration/collection state rather than pretending that confidence is proven accuracy.

The outcome tracker resolves signals from provider prices during repeated market scans. It is a validation layer, not a guarantee of future profit.

## Inherited FixPack 6 fixes
- Final 4-colour premium palette only:
  - `#F7F4ED`
  - `#2F2A25`
  - `#3E4A3F`
  - `#E6D8C3`
- Mehndi/olive background removed.
- Bottom nav: Home / Markets / Charts / Positions / More.
- AI moved into main/More navigation.
- Unified Paper + Real positions page.
- GoCharting host instead of silently falling back to the old Canvas chart.
- Feed reconnect noise reduced.
- Session persistence repair.
- One-best-trade notification flow.
- Entry / SL / 1:3 target / Support / Resistance displayed.

## Apply

From the extracted ZIP folder:

```bash
bash APPLY_FIXPACK_7_FINAL.sh ~/Projects/zerion-x1
```

The script:
1. Creates a backup.
2. Copies FixPack files.
3. Runs Python compile checks.
4. Runs `git diff --check`.
5. Runs `npm run typecheck`.
6. Runs tests.
7. Runs production build.

It does **not** commit or push automatically.

## Database migration

Deploy:

```text
supabase/migrations/20260823_fixpack7_signal_validation.sql
```

This creates the server-only signal outcome calibration table.

## Production checks after local build

1. Deploy Vercel.
2. Redeploy MT5 worker and MT5 gateway on Render.
3. Verify Worker/Gateway GET + HEAD health = 200.
4. Connect Exness demo from Zerion and verify `/session/verify` succeeds.
5. Execute a tiny demo-approved Forex setup and confirm Entry, SL and TP exist in MT5.
6. Confirm Upstox/CoinDCX live execution only with accounts that have trading permissions enabled.
7. Watch trailing with auto mode ON and OFF.

## Safety / execution semantics

Live trades are only sent after the user's explicit Approve action. Automatic quantity/volume is risk-sized from account balance/equity and the configured risk-per-trade controls. If risk sizing or provider instrument metadata cannot be resolved, execution fails instead of guessing a dangerous size.
