# Zerion X1 — Exness MT5 Multi-User Production Pack

Final routing:
- India -> Upstox
- Crypto -> CoinDCX
- Forex -> Exness MT5
- cTrader -> removed

Each Zerion user enters their own MT5 login, MT5 trading password, exact Exness MT5 server, and Demo/Real mode. Zerion verifies them through the MT5 bridge and stores only the existing AES-256-GCM encrypted credential envelope in broker_connections.

The bridge serializes access to the MetaTrader terminal, logs into the requesting user's account for the operation, returns the result, and shuts down that Python MT5 session.

Do not put any MT5 password in Git or source code.

Apply from Termux only after extracting:

cd ~/Projects/zerion-x1
bash ~/zxpack5prod/APPLY_FIXPACK_5_PRODUCTION.sh

The script stops if any cTrader source reference remains or typecheck fails.
