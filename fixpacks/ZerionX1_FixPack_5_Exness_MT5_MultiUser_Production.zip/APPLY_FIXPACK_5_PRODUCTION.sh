#!/usr/bin/env bash
set -euo pipefail
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f package.json ] || [ ! -d src ]; then
  echo "Run this from ~/Projects/zerion-x1"
  exit 1
fi

python3 "$PACK_DIR/patches/apply_pack5_production.py"

echo
echo "===== CTRADER AUDIT ====="
CTRADER_OUTPUT="$(grep -RniE 'ctrader|CTRADER|cTrader' src --exclude-dir=node_modules --exclude-dir=.next || true)"
if [ -n "$CTRADER_OUTPUT" ]; then
  echo "$CTRADER_OUTPUT"
  echo
  echo "STOP: cTrader references remain. Send this output before commit."
  exit 2
else
  echo "PASS: no cTrader references remain under src/"
fi

echo
echo "===== TYPECHECK ====="
npm run typecheck

echo
echo "Production MT5 coding applied."
