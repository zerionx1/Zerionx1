from pathlib import Path
import shutil, time

repo = Path.cwd()
pack = Path(__file__).resolve().parent.parent

required = [
    repo / "src/app/api/brokers/route.ts",
    repo / "src/config/brokers.ts",
    repo / "src/lib/brokers/oauth-config.ts",
    repo / "src/components/brokers/broker-connection-center.tsx",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    raise SystemExit("Missing Zerion files: " + ", ".join(missing))

backup = repo / ".fixpack-backups" / ("pack5-production-" + time.strftime("%Y%m%d-%H%M%S"))

def backup_item(path: Path):
    if not path.exists():
        return
    rel = path.relative_to(repo)
    dst = backup / rel
    if path.is_dir():
        shutil.copytree(path, dst, dirs_exist_ok=True)
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dst)

for rel in [
    "src/app/api/brokers/route.ts",
    "src/app/api/brokers/config-status/route.ts",
    "src/app/api/brokers/ctrader",
    "src/app/api/live/account/route.ts",
    "src/app/api/live/ctrader",
    "src/app/api/live/positions/exit/route.ts",
    "src/config/brokers.ts",
    "src/lib/brokers/oauth-config.ts",
    "src/lib/brokers/connection-store.ts",
    "src/lib/brokers/ctrader-json-client.ts",
    "src/components/brokers/broker-connection-center.tsx",
    "src/components/live/live-trading-command-center.tsx",
    "src/components/live/live-positions-workspace.tsx",
]:
    backup_item(repo / rel)

for rel in ["src/app/api/brokers/ctrader", "src/app/api/live/ctrader"]:
    p = repo / rel
    if p.exists():
        shutil.rmtree(p)

p = repo / "src/lib/brokers/ctrader-json-client.ts"
if p.exists():
    p.unlink()

for src in (pack / "src").rglob("*"):
    if src.is_file():
        dst = repo / src.relative_to(pack)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

bridge_dst = repo / "mt5-bridge"
bridge_dst.mkdir(parents=True, exist_ok=True)
for src in (pack / "mt5-bridge").rglob("*"):
    if src.is_file():
        dst = bridge_dst / src.relative_to(pack / "mt5-bridge")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

route = repo / "src/app/api/brokers/route.ts"
s = route.read_text()

needle = 'import { sealBrokerSecret } from "@/lib/brokers/token-vault";'
if 'mt5-bridge-client' not in s:
    s = s.replace(
        needle,
        needle + '\nimport { mt5BridgeClient, mt5BridgeConfigured } from "@/lib/brokers/mt5-bridge-client";',
        1,
    )

s = s.replace('return key === "upstox" || key === "ctrader";', 'return key === "upstox";', 1)

old_config = '''  if (key === "coindcx") {
    return Boolean(process.env.BROKER_TOKEN_ENCRYPTION_KEY);
  }
  return isOAuthBroker(key) ? brokerConfigured(key) : false;'''
new_config = '''  if (key === "coindcx") {
    return Boolean(process.env.BROKER_TOKEN_ENCRYPTION_KEY);
  }
  if (key === "exness-mt5") {
    return mt5BridgeConfigured();
  }
  return isOAuthBroker(key) ? brokerConfigured(key) : false;'''
if old_config not in s:
    raise SystemExit("Safety stop: configured() block changed. Send current broker route.")
s = s.replace(old_config, new_config, 1)

old_body = '''        apiKey?: string;
        apiSecret?: string;
      }'''
new_body = '''        apiKey?: string;
        apiSecret?: string;
        mt5Login?: string;
        mt5Password?: string;
        mt5Server?: string;
        mt5Environment?: "demo" | "real";
      }'''
if old_body not in s:
    raise SystemExit("Safety stop: broker POST body changed.")
s = s.replace(old_body, new_body, 1)

anchor = '''  if (!isOAuthBroker(broker.key)) {
    return fail(
      "BROKER_NOT_CONFIGURED",
      `${broker.name} is not enabled in this release.`,
      503,
    );
  }'''

mt5_block = '''  if (broker.key === "exness-mt5") {
    if (!mt5BridgeConfigured()) {
      return fail(
        "BROKER_NOT_CONFIGURED",
        "MT5_BRIDGE_URL, MT5_BRIDGE_TOKEN and BROKER_TOKEN_ENCRYPTION_KEY are required.",
        503,
      );
    }

    const login = body?.mt5Login?.trim() ?? "";
    const password = body?.mt5Password ?? "";
    const server = body?.mt5Server?.trim() ?? "";
    const environment = body?.mt5Environment === "real" ? "real" : "demo";

    if (!login || !password || !server) {
      return fail(
        "VALIDATION_ERROR",
        "MT5 login, trading password and server are required.",
        400,
      );
    }

    const credentials = { login, password, server, environment };

    try {
      const verified = await mt5BridgeClient.verify(credentials);
      const existing = (
        await select(
          "broker_connections",
          `owner_id=eq.${user.id}&broker_key=eq.exness-mt5&limit=1`,
        )
      )[0];

      const metadata = {
        provider: "exness-mt5",
        auth_mode: "user-mt5-credentials",
        token_envelope: sealBrokerSecret(credentials),
        verified_at: new Date().toISOString(),
        account_info_present: true,
        environment,
        verification: verified,
      };

      if (existing) {
        await update(
          "broker_connections",
          `id=eq.${String(existing.id)}&owner_id=eq.${user.id}`,
          { status: "connected", metadata, updated_at: new Date().toISOString() },
        );
      } else {
        await insert("broker_connections", {
          owner_id: user.id,
          broker_key: "exness-mt5",
          display_name: "Exness MT5",
          status: "connected",
          metadata,
        });
      }

      return ok({
        connected: true,
        brokerKey: "exness-mt5",
        authMode: "user-mt5-credentials",
        environment,
      });
    } catch (error) {
      return fail(
        "BROKER_AUTH_FAILED",
        error instanceof Error ? error.message : "Exness MT5 verification failed.",
        401,
      );
    }
  }

''' + anchor

if anchor not in s:
    raise SystemExit("Safety stop: broker OAuth anchor changed.")
s = s.replace(anchor, mt5_block, 1)
route.write_text(s)

marketing = repo / "src/components/marketing/zerion-pro-max-home.tsx"
if marketing.exists():
    text = marketing.read_text()
    text = text.replace("Upstox for Indian markets and cTrader for Forex. Crypto remains coming soon.", "Upstox for Indian markets, CoinDCX for crypto and Exness MT5 for Forex.")
    text = text.replace("Forex through cTrader", "Forex through Exness MT5")
    text = text.replace("Crypto · Coming soon", "Crypto · CoinDCX")
    marketing.write_text(text)

print("Production Exness MT5 multi-user pack applied.")
print("Backup:", backup)
