# Zerion X1 FixPack 4 — Completion Pack

This pack completes the coding gaps left after FixPacks 1, 2 and 3.

## Included

### Options / Greeks / IV / Payoff
- Connects directly to the existing authenticated Upstox option-chain APIs already present in Zerion.
- Automatically discovers the nearest available expiry if one is not supplied.
- Returns call/put LTP, OI, volume, IV and Greeks.
- Computes PCR, ATM strike and approximate max-pain from the live option chain.
- Builds payoff scenarios for:
  - Long Call
  - Long Put
  - Long Straddle
- No fabricated Greeks or IV values.

### Fundamentals
- Adds a provider adapter using public Yahoo Finance quote data as a zero-key fallback.
- Returns live/public fields when available:
  - market cap
  - trailing P/E
  - forward P/E
  - EPS
  - book value
  - price/book
  - dividend yield
  - 52-week high/low
  - average volume
- It fails cleanly if the upstream public endpoint blocks a symbol.

### Intelligence UI
- `/dashboard/intelligence` now actually loads:
  - current news sentiment,
  - fundamentals,
  - options chain/Greeks/IV/payoff,
  - technical scanner status,
  - existing chart intelligence.
- Options are shown only for instruments where the Upstox option chain exists.

### Mobile UI overhaul
- Replaces the mobile bottom navigation with larger icons/text and Intelligence access.
- Global dashboard mobile layout fixes:
  - larger base font
  - light luxury background
  - readable cards
  - safe horizontal overflow
  - better buttons and inputs
  - better mobile grids/tables
  - bigger page headings
  - improved safe-area spacing
- Keeps the requested Zerion palette:
  #E4E0DF #F7F4ED #8C8A81 #F3F1EC #6B8F7A #2F2A25 #3E4A3F #E6D8C3

## Apply order

Apply FixPack 1, then 2, then 3, then this pack.

```bash
cd ~/Projects/zerion-x1

rm -rf /tmp/zxpack4
mkdir -p /tmp/zxpack4
unzip -o /path/to/ZerionX1_FixPack_4_Completion.zip -d /tmp/zxpack4

bash /tmp/zxpack4/APPLY_FIXPACK_4.sh

npm run test
npm run build
```

This pack creates a timestamped backup in `.fixpack-backups/pack4-*`.
