#!/usr/bin/env python3
from pathlib import Path
import shutil, time

repo = Path.cwd()
pack = Path(__file__).resolve().parent.parent

required = [
    repo / "package.json",
    repo / "src/app/globals.css",
    repo / "src/components/intelligence/market-intelligence-hub.tsx",
    repo / "src/components/navigation/mobile-bottom-nav.tsx",
    repo / "src/lib/brokers/upstox-client.ts",
]
missing = [str(path) for path in required if not path.exists()]
if missing:
    raise SystemExit(
        "FixPack 4 expects FixPacks 1-3 and the Zerion repo. Missing: "
        + ", ".join(missing)
    )

# Guards for previous packs.
scanner = repo / "src/lib/agents/deterministic-scanner.ts"
if not scanner.exists() or "tradePlan" not in scanner.read_text():
    raise SystemExit(
        "FixPack 4 expects FixPack 2 first: upgraded opportunity engine not detected."
    )

gc_host = repo / "src/components/markets/gocharting-chart-host.tsx"
if not gc_host.exists():
    raise SystemExit(
        "FixPack 4 expects FixPack 3 first: GoCharting host not detected."
    )

stamp = time.strftime("%Y%m%d-%H%M%S")
backup = repo / ".fixpack-backups" / ("pack4-" + stamp)

targets = [
    "src/components/intelligence/market-intelligence-hub.tsx",
    "src/components/navigation/mobile-bottom-nav.tsx",
    "src/app/globals.css",
]
for rel in targets:
    src = repo / rel
    if src.exists():
        dst = backup / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

new_files = [
    "src/lib/intelligence/options-engine.ts",
    "src/app/api/intelligence/options/route.ts",
    "src/app/api/intelligence/fundamentals/route.ts",
    "src/components/intelligence/market-intelligence-hub.tsx",
    "src/components/navigation/mobile-bottom-nav.tsx",
]
for rel in new_files:
    src = pack / rel
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

css_path = repo / "src/app/globals.css"
css = css_path.read_text()
marker = "/* Zerion X1 FixPack 4 — completion/mobile/light luxury overrides */"
addition = (pack / "patches/pack4.css").read_text()
if marker not in css:
    css += "\n\n" + addition + "\n"
css_path.write_text(css)

print("FixPack 4 applied.")
print("Backup:", backup)
