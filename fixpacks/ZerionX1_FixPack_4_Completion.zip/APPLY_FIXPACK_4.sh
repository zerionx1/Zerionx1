#!/usr/bin/env bash
set -euo pipefail
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f package.json ] || [ ! -d src ]; then
  echo "Run this from the existing Zerion X1 repo root."
  exit 1
fi

echo "===== Zerion X1 FixPack 4 — Completion ====="
python3 "$PACK_DIR/patches/apply_pack4.py"

echo
echo "===== TYPECHECK ====="
npm run typecheck

echo
echo "FixPack 4 applied."
echo "Recommended:"
echo "  npm run test"
echo "  npm run build"
