#!/usr/bin/env python3
from pathlib import Path
import shutil, time

repo = Path.cwd()
pack = Path(__file__).resolve().parent.parent
required = [
    repo / "src/workers/realtime-worker.ts",
    repo / "src/hooks/use-zerion-market-stream.ts",
    repo / "src/lib/market-data/providers/upstox/socket.ts",
    repo / "src/components/markets/market-chart-terminal.tsx",
    repo / "src/app/globals.css",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    raise SystemExit("Run from Zerion X1 repo root. Missing: " + ", ".join(missing))

stamp = time.strftime("%Y%m%d-%H%M%S")
backup = repo / ".fixpack-backups" / ("pack1-" + stamp)
for path in required:
    rel = path.relative_to(repo)
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dst)

shutil.copy2(pack / "patches/use-zerion-market-stream.ts",
             repo / "src/hooks/use-zerion-market-stream.ts")
shutil.copy2(pack / "patches/upstox-socket.ts",
             repo / "src/lib/market-data/providers/upstox/socket.ts")

for rel in [
    Path("src/lib/gocharting/zerion-datafeed.ts"),
    Path("src/components/markets/gocharting-chart-host.tsx"),
]:
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(pack / rel, dst)

worker_path = repo / "src/workers/realtime-worker.ts"
worker = worker_path.read_text()

if 'const RECONNECT_MS = 5_000;' in worker:
    worker = worker.replace(
        'const RECONNECT_MS = 5_000;',
        '''const UPSTOX_RECONNECT_BASE_MS = 1_000;
const UPSTOX_RECONNECT_MAX_MS = 30_000;

function upstoxReconnectDelay(attempt: number) {
  const base = Math.min(
    UPSTOX_RECONNECT_MAX_MS,
    UPSTOX_RECONNECT_BASE_MS * 2 ** Math.min(5, attempt),
  );
  return Math.round(base * (0.8 + Math.random() * 0.4));
}

const upstoxReconnectAttempts = new Map<string, number>();''',
        1,
    )

needle = '''  let counted = false;

  let feedHandle: UpstoxFeedHandle | null = null;

  try {'''
if needle in worker:
    worker = worker.replace(
        needle,
        '''  let counted = false;

  let feedHandle: UpstoxFeedHandle | null = null;
  const reconnectKey = connection.connectionId || connection.ownerId || "market-data";

  try {''',
        1,
    )

needle = '''      mode: "full",
      onMessage: (message) => {'''
if needle in worker:
    worker = worker.replace(
        needle,
        '''      mode: "full",
      onOpen: () => {
        upstoxReconnectAttempts.set(reconnectKey, 0);
      },
      onMessage: (message) => {''',
        1,
    )

fixed = 'setTimeout(() => void runUpstoxConnection(connection), RECONNECT_MS);'
repl = '''const attempt = upstoxReconnectAttempts.get(reconnectKey) ?? 0;
          upstoxReconnectAttempts.set(reconnectKey, attempt + 1);
          setTimeout(
            () => void runUpstoxConnection(connection),
            upstoxReconnectDelay(attempt),
          );'''
worker = worker.replace(fixed, repl)

old = '''  await Promise.all(
    scan.connections.map((connection) => runUpstoxConnection(connection)),
  );'''
new = '''  // Shared chart market-data must not create a socket per trading user.
  // Prefer UPSTOX_ANALYTICS_TOKEN above; otherwise use one account only as
  // market-data fallback. User OAuth remains available for execution/P&L.
  const fallbackConnection = scan.connections[0];
  if (fallbackConnection) {
    await runUpstoxConnection(fallbackConnection);
  }'''
if old not in worker:
    raise SystemExit("Safety stop: expected Upstox multi-user socket block not found.")
worker = worker.replace(old, new, 1)
worker_path.write_text(worker)

terminal_path = repo / "src/components/markets/market-chart-terminal.tsx"
terminal = terminal_path.read_text()
old_import = 'import { ZerionProviderChart } from "@/components/markets/zerion-provider-chart";'
new_import = 'import { GoChartingChartHost } from "@/components/markets/gocharting-chart-host";'
if old_import not in terminal:
    raise SystemExit("Safety stop: chart terminal renderer import changed upstream.")
terminal = terminal.replace(old_import, new_import, 1)
if "<ZerionProviderChart" not in terminal:
    raise SystemExit("Safety stop: chart terminal renderer call changed upstream.")
terminal = terminal.replace("<ZerionProviderChart", "<GoChartingChartHost", 1)
terminal_path.write_text(terminal)

css_path = repo / "src/app/globals.css"
css = css_path.read_text()
marker = "/* Zerion X1 FixPack 1: chart/mobile stability */"
if marker not in css:
    css += '''
\n/* Zerion X1 FixPack 1: chart/mobile stability */
.zx-gocharting-host { position: relative; min-width: 0; width: 100%; }
.zx-gocharting-attribution {
  display: flex; justify-content: flex-end; padding: .35rem .6rem;
  font-size: .72rem; letter-spacing: .02em; opacity: .62;
}
.zx-chart-commandbar input { font-size: clamp(.95rem, 2.8vw, 1.08rem); }
.zx-chart-timeframes { scrollbar-width: none; overscroll-behavior-inline: contain; }
.zx-chart-timeframes::-webkit-scrollbar { display: none; }
.zx-chart-stage h2 { font-size: clamp(1.25rem, 4.5vw, 1.85rem); line-height: 1.12; }
@media (max-width: 768px) {
  .zx-chart-workspace { gap: .75rem; }
  .zx-chart-commandbar { align-items: stretch; gap: .65rem; }
  .zx-chart-search { width: 100%; min-height: 48px; }
  .zx-chart-search input { min-height: 44px; }
  .zx-chart-timeframes {
    display: flex; width: 100%; overflow-x: auto; gap: .4rem;
    padding-bottom: .15rem; -webkit-overflow-scrolling: touch;
  }
  .zx-chart-timeframes button {
    min-width: 46px; min-height: 40px; flex: 0 0 auto; font-size: .82rem;
  }
  .zx-chart-stage { border-radius: 18px; overflow: hidden; }
  .zx-chart-stage > header {
    align-items: flex-start; gap: .65rem; padding-inline: .85rem;
  }
  .zx-chart-stage .data-badge { font-size: .66rem; white-space: nowrap; }
  .zx-gocharting-host { touch-action: pan-x pan-y; }
}
'''
css_path.write_text(css)

print("FixPack 1 applied.")
print("Backup:", backup)
