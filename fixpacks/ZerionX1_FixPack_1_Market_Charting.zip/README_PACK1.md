# Zerion X1 FixPack 1/3 — Market Core + Charting Foundation

Target: existing `zerionx1/Zerionx1` repo. This does not create a new project.

## Included in Pack 1
- Upstox shared market-data connection instead of one market socket per connected trading user.
- Exponential reconnect + jitter instead of fixed reconnect loop.
- Browser feed-health fix: open gateway is not marked disconnected simply because one symbol is quiet for 15 seconds.
- Automatic subscription restore after reconnect.
- Imperative realtime bridge for chart engines.
- Provider-independent GoCharting datafeed adapter using Zerion search, historical candles and realtime stream.
- GoCharting chart host/mount point with safe existing-chart fallback.
- Larger/cleaner mobile chart controls and typography.
- Backups before changing existing files.

## Apply
```bash
cd ~/Projects/zerion-x1
rm -rf /tmp/zxpack1
mkdir -p /tmp/zxpack1
unzip -o /path/to/ZerionX1_FixPack_1_Market_Charting.zip -d /tmp/zxpack1
bash /tmp/zxpack1/APPLY_FIXPACK_1.sh
```

Then:
```bash
npm run test
npm run build
```

## Important GoCharting note
The datafeed and mount point are implemented in this pack. The official GoCharting production SDK itself is not bundled or faked because the official demo distributes it as a local/license-controlled SDK tarball. Until that bundle is supplied, Zerion's existing chart remains the fallback so the build stays functional.

## 3-pack plan
- Pack 1: realtime stability + GoCharting foundation + mobile chart.
- Pack 2: opportunity engine overhaul — LONG + SHORT, complete entry/SL/targets/trailing/max-loss/max-profit, dynamic expiry, anti-overtrading, remove BTC/SOL/ETH-only behavior.
- Pack 3: final official GoCharting SDK mount + news/fundamentals/options/screening modules + final mobile/desktop integration.

No live-market system can truthfully guarantee a fixed 70–80% directional win rate. We can calibrate, backtest and filter signals for quality, but the percentage cannot be guaranteed.
