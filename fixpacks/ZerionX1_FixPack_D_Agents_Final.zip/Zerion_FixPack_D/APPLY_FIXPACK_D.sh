#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ROOT="$(pwd)"
PACK="$(cd "$(dirname "$0")" && pwd)"

copy_file() {
  mkdir -p "$ROOT/$(dirname "$1")"
  cp "$PACK/$1" "$ROOT/$1"
}

copy_file "src/lib/supabase/admin-rest.ts"
copy_file "src/lib/agents/types.ts"
copy_file "src/lib/agents/orchestrator.ts"
copy_file "src/lib/agents/opportunity-store.ts"
copy_file "src/app/api/automation/market-scan/route.ts"
copy_file "src/app/api/agents/opportunities/route.ts"
copy_file "src/app/api/notifications/inbox/route.ts"
copy_file "src/app/api/agents/opportunities/[opportunityId]/approve/route.ts"
copy_file "src/components/notifications/agent-opportunity-inbox.tsx"
copy_file "src/app/dashboard/notifications/page.tsx"
copy_file "src/app/agent-finalization.css"
copy_file "supabase/migrations/20260819_agent_opportunities_notifications.sql"
copy_file "AGENT_ENV_NAMES.txt"

python - <<'PY'
from pathlib import Path
p = Path("src/app/globals.css")
s = p.read_text()
line = '@import "./agent-finalization.css";'
if line not in s:
    marker = '@import "./trading-workspace-v2.css";'
    if marker in s:
        s = s.replace(marker, marker + "\n" + line)
    else:
        s = line + "\n" + s
    p.write_text(s)
print("Agent finalization CSS import ensured.")
PY

echo "FixPack D applied."
echo "Migration file added but NOT applied to production Supabase automatically."
echo "Server secret values were NOT added."
